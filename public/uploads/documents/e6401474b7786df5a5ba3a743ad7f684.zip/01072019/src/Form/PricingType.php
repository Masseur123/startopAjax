<?php

namespace App\Form;

use App\Entity\Pricing;
use App\Entity\Hotel;
use App\Entity\HousingType;
use App\Entity\Housing;
use App\Entity\PricingPlan;

use Symfony\Component\Form\AbstractType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\MoneyType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class PricingType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('price', MoneyType::class, array(
                'currency' => 'XAF',
            ))
            ->add('p_min', CheckboxType::class, array(
                'attr' => array(
                    'class' => 'form-check-input-styled',
                ),
            ))
            ->add('p_max', CheckboxType::class, array(
                'attr' => array(
                    'class' => 'form-check-input-styled',
                ),
            ))
            ->add('ordering')
            ->add('housing', EntityType::class, array(
                'class' => Housing::class,
                'expanded' => false,
                'multiple' => false,
                'attr' => array(
                    'class' => 'form-control select-search',
                ),
            ))
            ->add('housingtype', EntityType::class, array(
                'class' => HousingType::class,
                'expanded' => false,
                'multiple' => false,
                'attr' => array(
                    'class' => 'form-control select-search',
                ),
            ))
            ->add('hotel', EntityType::class, array(
                'class' => Hotel::class,
                'expanded' => false,
                'multiple' => false,
                'attr' => array(
                    'class' => 'form-control select-search',
                ),
            ))
            ->add('pricingplan', EntityType::class, array(
                'class' => PricingPlan::class,
                'expanded' => false,
                'multiple' => false,
                'attr' => array(
                    'class' => 'form-control select-search',
                ),
            ))
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Pricing::class,
        ]);
    }
}
