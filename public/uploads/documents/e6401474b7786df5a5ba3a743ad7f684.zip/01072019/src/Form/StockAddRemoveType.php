<?php

namespace App\Form;

use App\Entity\Stock;
use App\Entity\Store;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class StockAddRemoveType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('quantity')
            ->add('stockAt', DateType::class, array(
                'widget' => 'single_text',
            ))
            ->add('stockprice')
            ->add('store',EntityType::class, array(
            'class'=> Store::class,
            'placeholder' => 'Choose an option',
            'expanded' => false,
            'multiple' => false,
            'attr' => array(
                'class' => 'form-control select-search',
            ),
        ))
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Stock::class,
        ]);
    }
}
