<?php

namespace App\Form;

use App\Entity\UserGroup;
use App\Entity\Role;

use App\Repository\RoleRepository;

use Symfony\Component\Form\AbstractType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class GroupRoleType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
		$value = $options['menuId'];
		
        $builder
			->add('roles',EntityType::class, array(
                'class' => Role::class,
                'query_builder' => function (RoleRepository $m) use ($value) {
                    return $m->createQueryBuilder('r')
                        ->andWhere('r.is_enabled = :isenable')
						->andWhere('r.menu = :value')
                        ->setParameter('isenable', true)
						->setParameter('value', $value)
                        ->orderBy('r.position', 'ASC');
                },
                'placeholder' => 'assign_roles',
                'expanded' => false,
                'multiple' => true,
                'required' => false,
				'translation_domain' => 'admin',
                'attr' => array(
                    'class' => 'form-control multiselect',
                ),
            ))
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => UserGroup::class,
        ]);
		$resolver->setRequired(['menuId']);
    }
}
