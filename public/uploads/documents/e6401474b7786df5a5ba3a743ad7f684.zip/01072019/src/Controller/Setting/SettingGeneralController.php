<?php

namespace App\Controller\Setting;

use App\Entity\Priority;
use App\Entity\ModeTransport;
use App\Entity\Port;
use App\Entity\BusinessType;
use App\Entity\Civility;
use App\Entity\Language;


use App\Form\PriorityType;
use App\Form\ModeTransportType;
use App\Form\PortType;
use App\Form\BusinessTypeType;
use App\Form\CivilityType;
use App\Form\LanguageType;

use App\Repository\PriorityRepository;
use App\Repository\ModeTransportRepository;
use App\Repository\PortRepository;
use App\Repository\BusinessTypeRepository;
use App\Repository\CivilityRepository;
use App\Repository\LanguageRepository;

use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Controller used to manage Financial Settings.
 *
 * @author Hervé Marcel Jiogue Tadie <fastochehost@gmail.com>
 * @author My Team <>
 */
class SettingGeneralController extends AbstractController
{
    /**
     * Creates a new Port entity.
     *
     * @Route("/port", methods={"GET", "POST"}, name="port")
     *
     */
    public function newPort(Request $request, PortRepository $ports, ObjectManager $em): Response
    {
        $port = new Port();

        // On Instancie le formulaire
        $form = $this->createForm(PortType::class, $port);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // On prépare l'objet à persister
            $port->setCreatedAt(new \DateTime());
            $port->setUser($this->getUser());

            $em->persist($port);
            $em->flush();

            $this->addFlash('success', 'Success!');

            return $this->redirectToRoute('port');
        }
        $userPorts = $ports->findBy([], ['id' => 'DESC']);

        return $this->render('setting_general/edit_port.html.twig', [
            'form' => $form->createView(),
            'ports' => $userPorts,
        ]);
    }

    /**
     * Displays a form to edit an existing Port entity.
     *
     * @Route("/port/{id<\d+>}/edit", methods={"GET", "POST"}, name="port_edit")
     *
     */
    public function editPort(Request $request, PortRepository $ports, Port $port, ObjectManager $em): Response
    {
        $form = $this->createForm(PortType::class, $port);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();

            $this->addFlash('success', 'Success!');

            return $this->redirectToRoute('port');
        }
        $userPorts = $ports->findBy([], ['id' => 'DESC']);

        return $this->render('setting_general/edit_port.html.twig', [
            'form' => $form->createView(),
            'ports' => $userPorts,
        ]);
    }

    /**
     * Deletes a Port entity.
     *
     * @Route("/port/{id}/delete", methods={"GET", "POST"}, name="port_delete")
     *
     */
    public function deletePort(Port $port, ObjectManager $em): Response
    {
        $em->remove($port);
        $em->flush();

        $this->addFlash('success', 'Success!');
        return $this->redirectToRoute('port');
    }

    /**
     * Creates a new business type entity.
     *
     * @Route("/business-type", methods={"GET", "POST"}, name="business_type")
     *
     */
    public function newBusinessType(Request $request, BusinessTypeRepository $businessTypes, ObjectManager $em): Response
    {
        $businessType = new BusinessType();

        // On Instancie le formulaire
        $form = $this->createForm(BusinessTypeType::class, $businessType);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // On prépare l'objet à persister
            $businessType->setCreatedAt(new \DateTime());
            $businessType->setUser($this->getUser());

            $em->persist($businessType);
            $em->flush();

            $this->addFlash('success', 'Success!');

            return $this->redirectToRoute('business_type');
        }
        $userBusinessTypes = $businessTypes->findBy([], ['id' => 'DESC']);

        return $this->render('setting_general/edit_business-type.html.twig', [
            'form' => $form->createView(),
            'businessTypes' => $userBusinessTypes,
        ]);
    }

    /**
     * Displays a form to edit an existing business type entity.
     *
     * @Route("/business-type/{id<\d+>}/edit",methods={"GET", "POST"}, name="business_type_edit")
     *
     */
    public function editBusinessType(Request $request, BusinessTypeRepository $businessTypes, BusinessType $businessType, ObjectManager $em): Response
    {
        $form = $this->createForm(BusinessTypeType::class, $businessType);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();

            $this->addFlash('success', 'Success!');
            return $this->redirectToRoute('business_type');
        }
        $userBusinessTypes = $businessTypes->findBy([], ['id' => 'DESC']);

        return $this->render('setting/edit_business-type.html.twig', [
            'form' => $form->createView(),
            'businessTypes' => $userBusinessTypes,
        ]);
    }

    /**
     * Deletes a business type entity.
     *
     * @Route("/business-type/{id}/delete", methods={"GET", "POST"}, name="business_type_delete")
     *
     */
    public function deleteBusinessType(BusinessType $businessType, ObjectManager $em): Response
    {
        $em->remove($businessType);
        $em->flush();

        $this->addFlash('success', 'Success!');
        return $this->redirectToRoute('business_type');
    }

    /**
     * Creates a new Mode trans entity.
     *
     * @Route("/mode-transport", methods={"GET", "POST"}, name="mode_transport")
     *
     */
    public function newModeTransport(Request $request, ModeTransportRepository $modeTransports, ObjectManager $em): Response
    {
        $modeTransport = new ModeTransport();

        // On Instancie le formulaire
        $form = $this->createForm(ModeTransportType::class, $modeTransport);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // On prépare l'objet à persister
            $modeTransport->setCreatedAt(new \DateTime());
            $modeTransport->setUser($this->getUser());

            $em->persist($modeTransport);
            $em->flush();

            $this->addFlash('success', 'Success!');

            return $this->redirectToRoute('mode_transport');
        }
        $userModeTransport = $modeTransports->findBy(['user' => $this->getUser()]);

        return $this->render('setting_general/edit_modetransport.html.twig', [
            'form' => $form->createView(),
            'modetransports' => $userModeTransport,
        ]);
    }

    /**
     * Displays a form to edit an existing Mode trans entity.
     *
     * @Route("/mode-transport/{id<\d+>}/edit",methods={"GET", "POST"}, name="mode_transport_edit")
     *
     */
    public function editModeTransport(Request $request, ModeTransportRepository $modeTransports, ModeTransport $modeTransport, ObjectManager $em): Response
    {
        $form = $this->createForm(ModeTransportType::class, $modeTransport);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();

            $this->addFlash('success', 'Success!');
            return $this->redirectToRoute('mode_transport');
        }
        $userModeTransport = $modeTransports->findBy(['user' => $this->getUser()]);

        return $this->render('setting_general/edit_modetransport.html.twig', [
            'form' => $form->createView(),
            'modetransports' => $userModeTransport,
        ]);
    }

    /**
     * Deletes a Mode trans entity.
     *
     * @Route("/mode-transport/{id}/delete", methods={"GET", "POST"}, name="mode_transport_delete")
     *
     */
    public function deleteModeTransport(ModeTransport $modeTransport, ObjectManager $em): Response
    {
        $em->remove($modeTransport);
        $em->flush();

        $this->addFlash('success', 'Success!');
        return $this->redirectToRoute('mode_transport');
    }

    /**
     * Creates a new Priority entity.
     *
     * @Route("/priority", methods={"GET", "POST"}, name="priority")
     *
     */
    public function newPriority(Request $request, PriorityRepository $priorities, ObjectManager $em): Response
    {
        $priority = new Priority();

        // On Instancie le formulaire 
        $form = $this->createForm(PriorityType::class, $priority);

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // On prépare l'objet à persister 
            $priority->setCreatedAt(new \DateTime());
            $priority->setUser($this->getUser());

            $em->persist($priority);
            $em->flush();

            $this->addFlash('success', 'Success!');

            return $this->redirectToRoute('priority');
        }
        $userPriorities = $priorities->findBy(['user' => $this->getUser()]);

        return $this->render('setting_general/edit_priority.html.twig', [
            'form' => $form->createView(),
            'priorities' => $userPriorities,
        ]);
    }

    /**
     * Displays a form to edit an existing Priority entity.
     *
     * @Route("/priority/{id<\d+>}/edit",methods={"GET", "POST"}, name="priority_edit")
     * 
     */
    public function editPriority(Request $request, PriorityRepository $priorities, Priority $priority, ObjectManager $em): Response
    {
        $form = $this->createForm(PriorityType::class, $priority);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();

            $this->addFlash('success', 'Success!');
            return $this->redirectToRoute('priority');
        }
        $userPriorities = $priorities->findBy(['user' => $this->getUser()]);

        return $this->render('setting_general/edit_priority.html.twig', [
            'form' => $form->createView(),
            'priorities' => $userPriorities,
        ]);
    }

    /**
     * Deletes a Priority entity.
     *
     * @Route("/priority/{id}/delete", methods={"GET", "POST"}, name="priority_delete")
     * 
     */
    public function deletePriority(Priority $priority, ObjectManager $em): Response
    {
        $em->remove($priority);
        $em->flush();

        $this->addFlash('success', 'Success!');
        return $this->redirectToRoute('priority');
    }

    /**
     * Creates a new Civility entity.
     *
     * @Route("/civility", methods={"GET", "POST"}, name="civility")
     *
     */
    public function newCivility(Request $request, CivilityRepository $civilities, ObjectManager $em): Response
    {
        $civility = new Civility();

        // On Instancie le formulaire
        $form = $this->createForm(CivilityType::class, $civility);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // On prépare l'objet à persister
            $civility->setCreatedAt(new \DateTime());
            $civility->setUser($this->getUser());

            $em->persist($civility);
            $em->flush();

            $this->addFlash('success', 'Success!');

            return $this->redirectToRoute('civility');
        }
        $userCivilities = $civilities->findBy(['user' => $this->getUser()]);

        return $this->render('setting_general/edit_civility.html.twig', [
            'form' => $form->createView(),
            'civilities' => $userCivilities,
        ]);
    }

    /**
     * Displays a form to edit an existing Civility entity.
     *
     * @Route("/civility/{id<\d+>}/edit",methods={"GET", "POST"}, name="civility_edit")
     *
     */
    public function editCivility(Request $request, CivilityRepository $civilities, Civility $civility, ObjectManager $em): Response
    {
        $form = $this->createForm(CivilityType::class, $civility);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();

            $this->addFlash('success', 'Success!');
            return $this->redirectToRoute('civility');
        }
        $userCivilities = $civilities->findBy(['user' => $this->getUser()]);

        return $this->render('setting_general/edit_civility.html.twig', [
            'form' => $form->createView(),
            'civilities' => $userCivilities,
        ]);
    }

    /**
     * Deletes a Civility entity.
     *
     * @Route("/civility/{id}/delete", methods={"GET", "POST"}, name="civility_delete")
     *
     */
    public function deleteCivility(Civility $civility, ObjectManager $em): Response
    {
        $em->remove($civility);
        $em->flush();

        $this->addFlash('success', 'Success!');
        return $this->redirectToRoute('civility');
    }

    /**
     * Creates a new Language entity.
     *
     * @Route("/language/", methods={"GET", "POST"}, name="language")
     *
     */
    public function newLanguage(Request $request, LanguageRepository $languages, ObjectManager $em): Response
    {
        $language = new Language();

        // On Instancie le formulaire
        $form = $this->createForm(LanguageType::class, $language);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // On prépare l'objet à persister
            $language->setCreatedAt(new \DateTime());
            $language->setUser($this->getUser());

            $em->persist($language);
            $em->flush();

            $this->addFlash('success', 'Success!');

            return $this->redirectToRoute('language');
        }
        $userLanguages = $languages->findBy(['user' => $this->getUser()]);

        return $this->render('setting_general/edit_language.html.twig', [
            'form' => $form->createView(),
            'languages' => $userLanguages,
        ]);
    }

    /**
     * Displays a form to edit an existing Language entity.
     *
     * @Route("/language/{id<\d+>}/edit",methods={"GET", "POST"}, name="language_edit")
     *
     */
    public function editLanguage(Request $request, LanguageRepository $languages, Language $language, ObjectManager $em): Response
    {
        $form = $this->createForm(LanguageType::class, $language);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();

            $this->addFlash('success', 'Success!');
            return $this->redirectToRoute('language');
        }
        $userLanguages = $languages->findBy(['user' => $this->getUser()]);

        return $this->render('setting_general/edit_language.html.twig', [
            'form' => $form->createView(),
            'languages' => $userLanguages,
        ]);
    }

    /**
     * Deletes a Language entity.
     *
     * @Route("/language/{id}/delete", methods={"GET", "POST"}, name="language_delete")
     *
     */
    public function deleteLanguage(Language $language, ObjectManager $em): Response
    {
        $em->remove($language);
        $em->flush();

        $this->addFlash('success', 'Success!');
        return $this->redirectToRoute('language');
    }
}
