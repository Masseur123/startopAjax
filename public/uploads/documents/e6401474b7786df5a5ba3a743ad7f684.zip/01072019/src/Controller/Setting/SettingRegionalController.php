<?php

namespace App\Controller\Setting;

use App\Entity\Country;
use App\Entity\Region;
use App\Entity\Division;
use App\Entity\Subdivision;


use App\Form\CountryType;
use App\Form\RegionType;
use App\Form\DivisionType;
use App\Form\SubdivisionType;

use App\Repository\CountryRepository;
use App\Repository\RegionRepository;
use App\Repository\DivisionRepository;
use App\Repository\SubdivisionRepository;

use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Controller used to manage Regional Settings.
 *
 * @author Hervé Marcel Jiogue Tadie <fastochehost@gmail.com>
 * @author My Team <>
 */
class SettingRegionalController extends AbstractController
{
    /**
     * Creates a new Country entity.
     *
     * @Route("/country", methods={"GET", "POST"}, name="country")
     *
     */
    public function newCountry(Request $request, CountryRepository $countries, ObjectManager $em): Response
    {
        $country = new Country();

        // On Instancie le formulaire
        $form = $this->createForm(CountryType::class, $country);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // On prépare l'objet à persister
            $country->setCreatedAt(new \DateTime());
            $country->setUser($this->getUser());

            $em->persist($country);
            $em->flush();

            // Flash messages are used to notify the user about the result of the
            // actions. They are deleted automatically from the session as soon
            // as they are accessed.
            // See https://symfony.com/doc/current/book/controller.html#flash-messages
            $this->addFlash('success', 'Success!');

            return $this->redirectToRoute('country');
        }
        $userCountries = $countries->findBy(['user' => $this->getUser()]);

        return $this->render( 'setting_regional/edit_country.html.twig', [
            'form' => $form->createView(),
            'countries' => $userCountries,
        ]);
    }

    /**
     * Displays a form to edit an existing Country entity.
     *
     * @Route("/country/{id<\d+>}/edit",methods={"GET", "POST"}, name="country_edit")
     *
     */
    public function editCountry(Request $request, CountryRepository $countries, Country $country, ObjectManager $em): Response
    {
        $form = $this->createForm(CountryType::class, $country);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();

            $this->addFlash('success', 'Success!');

            return $this->redirectToRoute('country');
        }
        $userCountries = $countries->findBy(['user' => $this->getUser()]);

        return $this->render( 'setting_regional/edit_country.html.twig', [
            'form' => $form->createView(),
            'countries' => $userCountries
        ]);
    }

    /**
     * Deletes a Country entity.
     *
     * @Route("/country/{id}/delete", methods={"GET", "POST"}, name="country_delete")
     *
     */
    public function deleteCountry(Request $request, Country $country, ObjectManager $em): Response
    {
        $em->remove($country);
        $em->flush();

        $this->addFlash('success', 'Success!');

        return $this->redirectToRoute('country');
    }

    /**
     * Creates a new Region entity.
     *
     * @Route("/region", methods={"GET", "POST"}, name="region")
     *
     */
    public function newRegion(Request $request, RegionRepository $regions, ObjectManager $em): Response
    {
        $region = new Region();

        // On Instancie le formulaire
        $form = $this->createForm(RegionType::class, $region);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // On prépare l'objet à persister
            $region->setCreatedAt(new \DateTime());
            $region->setUser($this->getUser());

            $em->persist($region);
            $em->flush();

            $this->addFlash('success', 'Success!');

            return $this->redirectToRoute('region');
        }
        $userRegions = $regions->findBy(['user' => $this->getUser()]);

        return $this->render( 'setting_regional/edit_region.html.twig', [
            'form' => $form->createView(),
            'regions' => $userRegions,
        ]);
    }

    /**
     * Displays a form to edit an existing Region entity.
     *
     * @Route("/region/{id<\d+>}/edit",methods={"GET", "POST"}, name="region_edit")
     *
     */
    public function editRegion(Request $request, RegionRepository $regions, Region $region, ObjectManager $em): Response
    {
        $form = $this->createForm(RegionType::class, $region);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();

            $this->addFlash('success', 'Success!');

            return $this->redirectToRoute('region');
        }
        $userRegions = $regions->findBy(['user' => $this->getUser()]);

        return $this->render( 'setting_regional/edit_region.html.twig', [
            'form' => $form->createView(),
            'regions' => $userRegions,
        ]);
    }

    /**
     * Deletes a Region entity.
     *
     * @Route("/region/{id}/delete", methods={"GET", "POST"}, name="region_delete")
     *
     */
    public function deleteRegion(Request $request, Region $region, ObjectManager $em): Response
    {
        $em->remove($region);
        $em->flush();

        $this->addFlash('success', 'Success!');

        return $this->redirectToRoute('region');
    }

    /**
     * Creates a new Division entity.
     *
     * @Route("/division", methods={"GET", "POST"}, name="division")
     *
     */
    public function newDivision(Request $request, DivisionRepository $divisions, ObjectManager $em): Response
    {
        $division = new Division();

        // On Instancie le formulaire
        $form = $this->createForm(DivisionType::class, $division);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // On prépare l'objet à persister
            $division->setCreatedAt(new \DateTime());
            $division->setUser($this->getUser());

            $em->persist($division);
            $em->flush();

            $this->addFlash('success', 'Success!');

            return $this->redirectToRoute('division');
        }
        $userDivisions = $divisions->findBy(['user' => $this->getUser()]);

        return $this->render( 'setting_regional/edit_division.html.twig', [
            'form' => $form->createView(),
            'divisions' => $userDivisions,
        ]);
    }

    /**
     * Displays a form to edit an existing Division entity.
     *
     * @Route("/division/{id<\d+>}/edit",methods={"GET", "POST"}, name="division_edit")
     *
     */
    public function editDivision(Request $request, DivisionRepository $divisions, Division $division, ObjectManager $em): Response
    {
        $form = $this->createForm(DivisionType::class, $division);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();

            $this->addFlash('success', 'Success!');

            return $this->redirectToRoute('division');
        }
        $userDivisions = $divisions->findBy(['user' => $this->getUser()]);

        return $this->render( 'setting_regional/edit_division.html.twig', [
            'form' => $form->createView(),
            'divisions' => $userDivisions,
        ]);
    }

    /**
     * Deletes a Division entity.
     *
     * @Route("/division/{id}/delete", methods={"GET", "POST"}, name="division_delete")
     *
     */
    public function deleteDivision(Request $request, Division $division, ObjectManager $em): Response
    {
        $em->remove($division);
        $em->flush();

        $this->addFlash('success', 'Success!');

        return $this->redirectToRoute('division');
    }

    /**
     * Creates a new Subdivision entity.
     *
     * @Route("/subdivision", methods={"GET", "POST"}, name="subdivision")
     *
     */
    public function newSubdivision(Request $request, SubdivisionRepository $subDivisions, ObjectManager $em): Response
    {
        $subDivision = new Subdivision();

        // On Instancie le formulaire
        $form = $this->createForm(SubdivisionType::class, $subDivision);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // On prépare l'objet à persister
            $subDivision->setCreatedAt(new \DateTime());
            $subDivision->setUser($this->getUser());

            $em->persist($subDivision);
            $em->flush();

            $this->addFlash('success', 'Success!');

            return $this->redirectToRoute('subdivision');
        }
        $userSubDivisions = $subDivisions->findBy(['user' => $this->getUser()]);

        return $this->render( 'setting_regional/edit_subdivision.html.twig', [
            'form' => $form->createView(),
            'subdivisions' => $userSubDivisions,
        ]);
    }

    /**
     * Displays a form to edit an existing Subdivision entity.
     *
     * @Route("/subdivision/{id<\d+>}/edit",methods={"GET", "POST"}, name="subdivision_edit")
     *
     */
    public function editSubdivision(Request $request, SubdivisionRepository $subDivisions, Subdivision $subDivision, ObjectManager $em): Response
    {
        $form = $this->createForm(SubdivisionType::class, $subDivision);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();

            $this->addFlash('success', 'Success!');

            return $this->redirectToRoute('subdivision');
        }
        $userSubDivisions = $subDivisions->findBy(['user' => $this->getUser()]);

        return $this->render( 'setting_regional/edit_subdivision.html.twig', [
            'form' => $form->createView(),
            'subdivisions' => $userSubDivisions,
        ]);
    }

    /**
     * Deletes a Subdivision entity.
     *
     * @Route("/subdivision/{id}/delete", methods={"GET", "POST"}, name="subdivision_delete")
     *
     */
    public function deleteSubdivision(Request $request, Subdivision $subDivision, ObjectManager $em): Response
    {
        $em->remove($subDivision);
        $em->flush();

        $this->addFlash('success', 'Success!');

        return $this->redirectToRoute('subdivision');
    }
}
