<?php

namespace App\Controller\Setting;

use App\Entity\PaymentMethod;
use App\Entity\Year;
use App\Entity\Tax;
use App\Entity\Currency;

use App\Form\PaymentMethodType;
use App\Form\YearType;
use App\Form\TaxType;
use App\Form\CurrencyType;

use App\Repository\PaymentMethodRepository;
use App\Repository\YearRepository;
use App\Repository\TaxRepository;
use App\Repository\CurrencyRepository;

use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Controller used to manage Financial Settings.
 *
 * @author Hervé Marcel Jiogue Tadie <fastochehost@gmail.com>
 * @author My Team <>
 */
class SettingFinancialController extends AbstractController
{
    /**
     * Creates a new Year entity.
     *
     * @Route("/year", methods={"GET", "POST"}, name="year")
     *
     */
    public function newYear(Request $request, YearRepository $years, ObjectManager $em): Response
    {
        $year = new Year();

        // On Instancie le formulaire
        $form = $this->createForm(YearType::class, $year);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // On prépare l'objet à persister
            $year->setCreatedAt(new \DateTime());
            $year->setUser($this->getUser());

            $em->persist($year);
            $em->flush();

            $this->addFlash('success', 'Success!');

            return $this->redirectToRoute('year');
        }
        $userYears = $years->findBy([], ['id' => 'DESC']);

        return $this->render('setting_financial/edit_year.html.twig', [
            'form' => $form->createView(),
            'years' => $userYears,
        ]);
    }

    /**
     * Displays a form to edit an existing Year entity.
     *
     * @Route("/year/{id<\d+>}/edit", methods={"GET", "POST"}, name="year_edit")
     *
     */
    public function editYear(Request $request, YearRepository $years, Year $year, ObjectManager $em): Response
    {
        $form = $this->createForm(YearType::class, $year);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();

            $this->addFlash('success', 'Success!');

            return $this->redirectToRoute('year');
        }
        $userYears = $years->findBy([], ['id' => 'DESC']);

        return $this->render('setting_financial/edit_year.html.twig', [
            'form' => $form->createView(),
            'years' => $userYears,
        ]);
    }

    /**
     * Deletes a Year entity.
     *
     * @Route("/year/{id}/delete", methods={"GET", "POST"}, name="year_delete")
     *
     */
    public function deleteYear(Request $request, Year $year, ObjectManager $em): Response
    {
        $em->remove($year);
        $em->flush();

        $this->addFlash('success', 'Success!');
        return $this->redirectToRoute('year');
    }

    /**
     * Creates a new Language entity.
     *
     * @Route("/tax", methods={"GET", "POST"}, name="tax")
     *
     */
    public function newTax(Request $request, TaxRepository $taxes, ObjectManager $em): Response
    {
        $tax = new Tax();

        // On Instancie le formulaire
        $form = $this->createForm(TaxType::class, $tax);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // On prépare l'objet à persister
            $tax->setCreatedAt(new \DateTime());
            $tax->setUser($this->getUser());

            $em->persist($tax);
            $em->flush();

            $this->addFlash('success', 'Success!');

            return $this->redirectToRoute('tax');
        }
        $userTaxes = $taxes->findBy(['user' => $this->getUser()]);

        return $this->render('setting_financial/edit_tax.html.twig', [
            'form' => $form->createView(),
            'taxes' => $userTaxes,
        ]);
    }

    /**
     * Displays a form to edit an existing Language entity.
     *
     * @Route("/tax/{id<\d+>}/edit",methods={"GET", "POST"}, name="tax_edit")
     *
     */
    public function editTax(Request $request, TaxRepository $taxes, Tax $tax, ObjectManager $em): Response
    {
        $form = $this->createForm(TaxType::class, $tax);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();

            $this->addFlash('success', 'Success!');

            return $this->redirectToRoute('tax');
        }
        $userTaxes = $taxes->findBy(['user' => $this->getUser()]);

        return $this->render('setting_financial/edit_tax.html.twig', [
            'form' => $form->createView(),
            'taxes' => $userTaxes,
        ]);
    }

    /**
     * Deletes a Language entity.
     *
     * @Route("/tax/{id}/delete", methods={"GET", "POST"}, name="tax_delete")
     *
     */
    public function deleteTax(Tax $tax, ObjectManager $em): Response
    {
        $em->remove($tax);
        $em->flush();

        $this->addFlash('success', 'Success!');
        return $this->redirectToRoute('tax');
    }

    /**
     * Creates a new Currency entity.
     *
     * @Route("/currency", methods={"GET", "POST"}, name="currency")
     *
     */
    public function newCurrency(Request $request, CurrencyRepository $currencies, ObjectManager $em): Response
    {
        $currency = new Currency();

        // On Instancie le formulaire
        $form = $this->createForm(CurrencyType::class, $currency);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // On prépare l'objet à persister
            $currency->setCreatedAt(new \DateTime());
            $currency->setUser($this->getUser());
            $currency->setIsCurrent(false);

            $em->persist($currency);
            $em->flush();

            $this->addFlash('success', 'Success!');

            return $this->redirectToRoute('currency');
        }
        $userCurrencies = $currencies->findBy(['user' => $this->getUser()]);

        return $this->render( 'setting_financial/edit_currency.html.twig', [
            'form' => $form->createView(),
            'currencies' => $userCurrencies,
        ]);
    }

    /**
     * Displays a form to edit an existing Currency entity.
     *
     * @Route("/currency/{id<\d+>}/edit",methods={"GET", "POST"}, name="currency_edit")
     *
     */
    public function editCurrency(Request $request, CurrencyRepository $currencies, Currency $currency, ObjectManager $em): Response
    {
        $form = $this->createForm(CurrencyType::class, $currency);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();

            $this->addFlash('success', 'Success!');
            return $this->redirectToRoute('currency');
        }
        $userCurrencies = $currencies->findBy(['user' => $this->getUser()]);

        return $this->render( 'setting_financial/edit_currency.html.twig', [
            'form' => $form->createView(),
            'currencies' => $userCurrencies,
        ]);
    }

    /**
     * Deletes a Region entity.
     *
     * @Route("/currency/{id}/delete", methods={"GET", "POST"}, name="currency_delete")
     *
     */
    public function deleteCurrency(Request $request, Currency $currency, ObjectManager $em): Response
    {
        $em->remove($currency);
        $em->flush();

        $this->addFlash('success', 'Success!');
        return $this->redirectToRoute('currency');
    }

    /**
     * Creates a new payment method entity.
     *
     * @Route("/payment-method", methods={"GET", "POST"}, name="payment_method")
     *
     */
    public function newPaymentMethod(Request $request, PaymentMethodRepository $paymentMethods, ObjectManager $em): Response
    {
        $paymentMethod = new PaymentMethod();

        // On Instancie le formulaire
        $form = $this->createForm(PaymentMethodType::class, $paymentMethod);

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // On prépare l'objet à persister
            $paymentMethod->setCreatedAt(new \DateTime());
            $paymentMethod->setUser($this->getUser());

            $em->persist($paymentMethod);
            $em->flush();

            $this->addFlash('success', 'Success!');
            return $this->redirectToRoute('payment_method');
        }
        $userPaymentMethods = $paymentMethods->findBy(['user' => $this->getUser()], ['createdAt' => 'DESC']);

        return $this->render('setting_financial/edit_paymentmethod.html.twig', [
            'form' => $form->createView(),
            'paymentmethods' => $userPaymentMethods,
        ]);
    }

    /**
     * Displays a form to edit an existing payment method entity.
     *
     * @Route("/payment-method/{id<\d+>}/edit",methods={"GET", "POST"}, name="payment_method_edit")
     *
     */
    public function editPaymentMethod(Request $request, PaymentMethodRepository $paymentMethods, PaymentMethod $paymentMethod, ObjectManager $em): Response
    {
        $form = $this->createForm(PaymentMethodType::class, $paymentMethod);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();

            $this->addFlash('success', 'Success!');
            return $this->redirectToRoute('payment_method');
        }
        $userPaymentMethods = $paymentMethods->findBy(['user' => $this->getUser()], ['createdAt' => 'DESC']);

        return $this->render('setting_financial/edit_paymentmethod.html.twig', [
            'form' => $form->createView(),
            'paymentmethods' => $userPaymentMethods,
        ]);
    }

    /**
     * Deletes a payment method entity.
     *
     * @Route("/payment-method/{id}/delete", methods={"GET", "POST"}, name="payment_method_delete")
     *
     */
    public function PaymentmethodDelete(Request $request, PaymentMethod $paymentMethod, ObjectManager $em): Response
    {

        $em->remove($paymentMethod);
        $em->flush();

        $this->addFlash('success', 'Success!');
        return $this->redirectToRoute('payment_method');
    }
}
