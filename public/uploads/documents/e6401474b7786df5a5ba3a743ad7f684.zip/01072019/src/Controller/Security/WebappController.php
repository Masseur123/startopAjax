<?php

namespace App\Controller\Security;


use App\Entity\Component;
use App\Entity\Role;

use App\Repository\ComponentRepository;
use App\Repository\RoleRepository;

use App\Form\ComponentType;
use App\Form\RoleType;

use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Controller used to manage system item.
 *
 * @author Hervé Marcel Jiogue Tadie <fastochehost@gmail.com>
 * @author My Team <>
 */
class WebappController extends AbstractController
{
    /**
     * Create a new Component entity.
     *
     * @Route("{_locale}/component", methods={"GET", "POST"}, name="component")
     *
     */
    public function newComponent(Request $request, ComponentRepository $components, Component $component = null, ObjectManager $em): Response
    {
        if (!$component) {
            $component = new Component();
        }

        // On Instancie le formulaire
        $form = $this->createForm(ComponentType::class, $component);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // On prépare l'objet à persister
            $component->setIsEnabled(true);

            $em->persist($component);
            $em->flush();

            $this->addFlash('success', 'Success!');

            return $this->redirectToRoute('component');
        }
        $userComponents = $components->findBy([], ['position' => 'ASC']);

        return $this->render('webapp/edit_component.html.twig', [
            'component' => $component,
            'form' => $form->createView(),
            'components' => $userComponents,
        ]);
    }

    /**
     * Displays a form to edit an existing Component entity.
     *
     * @Route("{_locale}/component/{id<\d+>}/edit", methods={"GET", "POST"}, name="component_edit")
     *
     */
    public function editComponent(Request $request, ComponentRepository $components, Component $component, ObjectManager $em): Response
    {
        $form = $this->createForm(ComponentType::class, $component);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();

            $this->addFlash('success', 'Success!');

            return $this->redirectToRoute('component');
        }
        $userComponents = $components->findBy([], ['position' => 'ASC']);

        return $this->render('webapp/edit_component.html.twig', [
            'component' => $component,
            'form' => $form->createView(),
            'components' => $userComponents,
        ]);
    }

    /**
     * Deletes a Component entity.
     *
     * @Route("{_locale}/component/{id}/delete", methods={"GET", "POST"}, name="component_delete")
     *
     */
    public function deleteComponent(Component $component, ObjectManager $em): Response
    {
        $em->remove($component);
        $em->flush();

        $this->addFlash('success', 'Success!');

        return $this->redirectToRoute('component');
    }
	
	/**
     * Enabled a component entity.
     *
     * @Route("_locale}/component/{id}/enabled", methods={"GET", "POST"}, name="component_enabled")
     *
     */
    public function enabledComponent(Component $component, ObjectManager $em): Response
    {
        $component->setIsEnabled(true);

        $em->flush();

        $this->addFlash('success', 'Success!');

        return $this->redirectToRoute('component');
    }

    /**
     * Blocked a component entity.
     *
     * @Route("_locale}/component/{id}/blocked", methods={"GET", "POST"}, name="component_blocked")
     *
     */
    public function blockedComponent(Component $component, ObjectManager $em): Response
    {
        $component->setIsEnabled(false);

        $em->flush();

        $this->addFlash('success', 'Success!');

        return $this->redirectToRoute('component');
    }

    /**
     * Creates a new Role entity.
     *
     * @Route("{_locale}/role", methods={"GET", "POST"}, name="role")
     *
     */
    public function newRole(Request $request, RoleRepository $roles, Role $role = null, ObjectManager $em): Response
    {
        if (!$role) {
            $role = new Role();
        }

        // On Instancie le formulaire 
        $form = $this->createForm(RoleType::class, $role);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // On prépare l'objet à persister 
            $role->setCreatedAt(new \DateTime());
            $role->setIsEnabled(true);

            $em->persist($role);
            $em->flush();

            $this->addFlash('success', 'Success!');

            return $this->redirectToRoute('role');
        }
        $userRoles = $roles->findBy([], ['id' => 'DESC']);

        return $this->render('webapp/edit_role.html.twig', [
            'role' => $role,
            'form' => $form->createView(),
            'roles' => $userRoles,
        ]);
    }

    /**
     * Displays a form to edit an existing Role entity.
     *
     * @Route("{_locale}/role/{id<\d+>}/edit",methods={"GET", "POST"}, name="role_edit")
     * 
     */
    public function editRole(Request $request, RoleRepository $roles, Role $role, ObjectManager $em): Response
    {
        $form = $this->createForm(RoleType::class, $role);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();

            $this->addFlash('success', 'Success!');

            return $this->redirectToRoute('role');
        }
        $userRoles = $roles->findBy([], ['id' => 'DESC']);

        return $this->render('webapp/edit_role.html.twig', [
            'role' => $role,
            'form' => $form->createView(),
            'roles' => $userRoles,
        ]);
    }

    /**
     * Deletes a Role entity.
     *
     * @Route("{_locale}/role/{id}/delete", methods={"GET", "POST"}, name="role_delete")
     * 
     */
    public function deleteRole(Role $role, ObjectManager $em): Response
    {
        $em->remove($role);
        $em->flush();

        $this->addFlash('success', 'Success!');

        return $this->redirectToRoute('role');
    }
	
	/**
     * Enabled a role entity.
     *
     * @Route("_locale}/role/{id}/enabled", methods={"GET", "POST"}, name="role_enabled")
     *
     */
    public function enabledRole(Role $role, ObjectManager $em): Response
    {
        $role->setIsEnabled(true);

        $em->flush();

        $this->addFlash('success', 'Success!');

        return $this->redirectToRoute('role');
    }

    /**
     * Blocked a role entity.
     *
     * @Route("_locale}/role/{id}/blocked", methods={"GET", "POST"}, name="role_blocked")
     *
     */
    public function blockedRole(Role $role, ObjectManager $em): Response
    {
        $role->setIsEnabled(false);

        $em->flush();

        $this->addFlash('success', 'Success!');

        return $this->redirectToRoute('role');
    }
}
