<?php

namespace App\Controller\Security;

use App\Entity\Component;

use App\Repository\GroupComponentRoleRepository;


use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Response;
use Doctrine\Common\Collections\ArrayCollection;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Session\Session;

/**
 * Controller used to manage roles in StarTop.
 *
 * @author Hervé Marcel Jiogue Tadie <fastochehost@gmail.com>
 * @author My Team <>
 */
class StartopController extends AbstractController
{
    /**
     * @Route("{_locale}/account_setting", methods={"GET", "POST"}, name="account_setting")
     * 
     */
    public function componentSetting(): Response
    {
        // Get current user's groups : [user_group_user] getUserGroups()
        $userGroups = $this->getUser()->getUserGroups();

        // Create an array collection for user's components 
        $userComponents = new ArrayCollection();

        // Load all components assigned to each group : [user_group_component] getComponents
        foreach ($userGroups as $userGroup) {
            // For each user's group get it's components  
            $groupComponents = $userGroup->getComponents();

            // For each group's component check if it is in $userComponents array colletion 
            foreach ($groupComponents as $groupComponent) {
                if (!$userComponents->contains($groupComponent) && $groupComponent->getIsEnabled()) {
                    $userComponents[] = $groupComponent;
                }
            }
        }

        return $this->render('startop/account-setting.html.twig', [
            'userComponents' => $userComponents,
        ]);
    }


    /**
     * Load one Component with all the roles.
     *
     * @Route("{_locale}/{id<\d+>}/component-loading", methods={"GET", "POST"}, name="component_loading")
     *
     */
    public function componentLoading(Component $component, GroupComponentRoleRepository $groupComponentRoles): Response
    {
        // We need group - component - > to query corresponding roles in [groupcomponentrole]
        // We already have component as id 
        // So it is remaining group ?

        // Get current user's groups : [user_group_user] getUserGroups()
        $userGroups = $this->getUser()->getUserGroups();

        // Create an array collection for component's menus 
        $menus = new ArrayCollection();

        // Create an array collection for component's roles 
        $roles = new ArrayCollection();

        foreach ($userGroups as $userGroup) {
            // Query in groupcomponentrole where $userGroup - $component
            $groupComponentRoleResults = $groupComponentRoles->findByGroupAndComponent($userGroup, $component);

            foreach ($groupComponentRoleResults as $groupComponentRoleResult) {
                if (!$groupComponentRoleResult->getRole()->getMenu() && !$menus->contains($groupComponentRoleResult->getRole())) {
                    $menus[] = $groupComponentRoleResult->getRole();
                }

                if ($groupComponentRoleResult->getRole()->getMenu() && !$roles->contains($groupComponentRoleResult->getRole())) {
                    $roles[] = $groupComponentRoleResult->getRole();
                }
            }
        }


        $session = new Session();
        //$session->start();

        // set menu and role session attributes
        $session->set('menu', $menus);
        $session->set('role', $roles);
        //$sessMenus = $session->get('menu');

        /*foreach ($sessMenus as $sessMenu) {
            var_dump($sessMenu->getName());
        }
        die;*/

        /*return $this->render('startop/component-loading.html.twig', [
            'menus' => $menus,
            'roles' => $roles,
        ]);*/
        return $this->redirectToRoute('transit_dashboard');
    }
}
