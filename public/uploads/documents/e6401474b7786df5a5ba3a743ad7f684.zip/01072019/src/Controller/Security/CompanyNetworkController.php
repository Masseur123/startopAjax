<?php

namespace App\Controller\Security;

use App\Entity\Institution;
use App\Entity\Branch;

use App\Form\InstitutionType;
use App\Form\BranchType;

use App\Repository\InstitutionRepository;
use App\Repository\BranchRepository;

use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;


/**
 * Controller used to manage company network in StarTop.
 *
 * @author Hervé Marcel Jiogue Tadie <fastochehost@gmail.com>
 * @author My Team <>
 */
class CompanyNetworkController extends AbstractController
{
    /**
     * Creates a new Institution entity.
     *
     * @Route("{_locale}/institution", methods={"GET", "POST"}, name="institution")
     *
     */
    public function newInstitution(Request $request, InstitutionRepository $institutions, ObjectManager $em): Response
    {
        $institution = new Institution();

        // On Instancie le formulaire
        $form = $this->createForm(InstitutionType::class, $institution);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // On prépare l'objet à persister
            $institution->setCreatedAt(new \DateTime());
            $institution->setUser($this->getUser());

            $em->persist($institution);
            $em->flush();

            $this->addFlash('success', 'Success!');

            return $this->redirectToRoute('institution');
        }
        $userInstitutions = $institutions->findBy([], ['id' => 'DESC']);

        return $this->render('company_network/edit_institution.html.twig', [
            'form' => $form->createView(),
            'institutions' => $userInstitutions,
        ]);
    }

    /**
     * Displays a form to edit an existing Institution entity.
     *
     * @Route("{_locale}/institution/{id<\d+>}/edit", methods={"GET", "POST"}, name="institution_edit")
     *
     */
    public function editInstitution(Request $request, Institution $institution, InstitutionRepository $institutions, ObjectManager $em): Response
    {
        $form = $this->createForm(InstitutionType::class, $institution);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();

            $this->addFlash('success', 'Success!');
            return $this->redirectToRoute('institution');
        }
        $userInstitutions = $institutions->findBy([], ['id' => 'DESC']);
        return $this->render('company_network/edit_institution.html.twig', [
            'institution' => $institution,
            'form' => $form->createView(),
            'institutions' => $userInstitutions,
        ]);
    }

    /**
     * Deletes a Institution entity.
     *
     * @Route("{_locale}/institution/{id}/delete", methods={"GET", "POST"}, name="institution_delete")
     *
     */
    public function deleteInstitution(Institution $institution, ObjectManager $em): Response
    {
        $em->remove($institution);
        $em->flush();

        $this->addFlash('success', 'Success!');
        return $this->redirectToRoute('institution');
    }



    /**
     * Creates a new Branch entity.
     *
     * @Route("{_locale}/branch", methods={"GET", "POST"}, name="branch")
     *
     */
    public function newBranch(Request $request, BranchRepository $branchs, ObjectManager $em): Response
    {
        $branch = new Branch();

        // On Instancie le formulaire
        $form = $this->createForm(BranchType::class, $branch);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // On prépare l'objet à persister
            $branch->setCreatedAt(new \DateTime());
            $branch->setUser($this->getUser());

            $em->persist($branch);
            $em->flush();

            $this->addFlash('success', 'Success!');
            return $this->redirectToRoute('branch');
        }
        $branches = $branchs->findBy([], ['id' => 'DESC']);

        return $this->render('company_network/edit_branch.html.twig', [
            'form' => $form->createView(),
            'branches' => $branches,
        ]);
    }

    /**
     * Displays a form to edit an existing Branch entity.
     *
     * @Route("{_locale}/branch/{id<\d+>}/edit", methods={"GET", "POST"}, name="branch_edit")
     *
     */
    public function editBranch(Request $request, Branch $branch, BranchRepository $branchs, ObjectManager $em): Response
    {
        $form = $this->createForm(BranchType::class, $branch);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();

            $this->addFlash('success', 'Success!');
            return $this->redirectToRoute('branch');
        }
        $branches = $branchs->findBy([], ['id' => 'DESC']);
        return $this->render('company_network/edit_branch.html.twig', [
            'branch' => $branch,
            'form' => $form->createView(),
            'branches' => $branches,
        ]);
    }

    /**
     * Deletes a Branch entity.
     *
     * @Route("{_locale}/branch/{id}/delete", methods={"GET", "POST"}, name="branch_delete")
     *
     */
    public function deleteBranch(Branch $branch, ObjectManager $em): Response
    {
        $em->remove($branch);
        $em->flush();

        $this->addFlash('success', 'Success!');
        return $this->redirectToRoute('branch');
    }
}
