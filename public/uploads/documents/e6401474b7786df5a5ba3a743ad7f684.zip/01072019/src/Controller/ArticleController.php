<?php

namespace App\Controller;

use App\Entity\Article;
use App\Entity\Family;
use App\Entity\Serial;
use App\Entity\Unity;

use App\Form\ArticleType;
use App\Form\FamilyType;
use App\Form\SerialType;
use App\Form\UnityType;

use App\Repository\ArticleRepository;
use App\Repository\FamilyRepository;
use App\Repository\SerialRepository;
use App\Repository\UnityRepository;

use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Controller used to manage article in ZoZoo.
 *
 * @author Hervé Marcel Jiogue Tadie <fastochehost@gmail.com>
 * @author My Team <>
 */
class ArticleController extends AbstractController
{
    /**
     * Creates a new Family entity.
     *
     * @Route("/family", methods={"GET", "POST"}, name="family")
     *
     */
    public function newFamily(Request $request, FamilyRepository $families, Family $family = null, ObjectManager $em) : Response
    {
        if (!$family) {
            $family = new Family();
        }

        // On Instancie le formulaire
        $form = $this->createForm(FamilyType::class, $family);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // On prépare l'objet à persister
            $family->setCreatedAt(new \DateTime());
            $family->setUser($this->getUser());

            $em->persist($family);
            $em->flush();

            $this->addFlash('success', 'created_successfully');

            return $this->redirectToRoute('family');
        }
        $userFamilies = $families->findBy(['user' => $this->getUser()]);

        return $this->render('article/edit_family.html.twig', [
            'family' => $family,
            'form' => $form->createView(),
            'families' => $userFamilies,
        ]);
    }

    /**
     * Displays a form to edit an existing Family entity.
     *
     * @Route("/family/{id<\d+>}/edit",methods={"GET", "POST"}, name="family_edit")
     *
     */
    public function editFamily(Request $request, FamilyRepository $families, Family $family, ObjectManager $em) : Response
    {
        $form = $this->createForm(FamilyType::class, $family);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();

            $this->addFlash('success', 'updated_successfully');

            return $this->redirectToRoute('family');
        }
        $userFamilies = $families->findBy(['user' => $this->getUser()]);

        return $this->render('article/edit_family.html.twig', [
            'family' => $family,
            'form' => $form->createView(),
            'families' => $userFamilies,
        ]);
    }

    /**
     * Deletes a Family entity.
     *
     * @Route("/family/{id}/delete", methods={"GET", "POST"}, name="family_delete")
     *
     */
    public function deleteFamily(Family $family, ObjectManager $em) : Response
    {
        $em->remove($family);
        $em->flush();

        $this->addFlash('success', 'deleted_successfully');

        return $this->redirectToRoute('family');
    }

    /**
     * Creates a new Unity entity.
     *
     * @Route("/unity", methods={"GET", "POST"}, name="unity")
     *
     */
    public function newUnity(Request $request, UnityRepository $unities, Unity $unity = null, ObjectManager $em) : Response
    {
        if (!$unity) {
            $unity = new Unity();
        }

        // On Instancie le formulaire
        $form = $this->createForm(UnityType::class, $unity);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // On prépare l'objet à persister
            $unity->setCreatedAt(new \DateTime());
            $unity->setUser($this->getUser());

            $em->persist($unity);
            $em->flush();

            $this->addFlash('success', 'created_successfully');

            return $this->redirectToRoute('unity');
        }
        $userUnities = $unities->findBy(['user' => $this->getUser()]);

        return $this->render('article/edit_unity.html.twig', [
            'unity' => $unity,
            'form' => $form->createView(),
            'unities' => $userUnities,
        ]);
    }

    /**
     * Displays a form to edit an existing Unity entity.
     *
     * @Route("/unity/{id<\d+>}/edit",methods={"GET", "POST"}, name="unity_edit")
     *
     */
    public function editUnity(Request $request, UnityRepository $unities, Unity $unity, ObjectManager $em) : Response
    {
        $form = $this->createForm(UnityType::class, $unity);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();

            $this->addFlash('success', 'updated_successfully');

            return $this->redirectToRoute('unity');
        }
        $userUnities = $unities->findBy(['user' => $this->getUser()]);

        return $this->render('article/edit_unity.html.twig', [
            'unity' => $unity,
            'form' => $form->createView(),
            'unities' => $userUnities,
        ]);
    }

    /**
     * Deletes a Unity entity.
     *
     * @Route("/unity/{id}/delete", methods={"GET", "POST"}, name="unity_delete")
     *
     */
    public function deleteUnity(Unity $unity, ObjectManager $em) : Response
    {
        $em->remove($unity);
        $em->flush();

        $this->addFlash('success', 'deleted_successfully');

        return $this->redirectToRoute('unity');
    }

    /**
     * Creates a new Article entity.
     *
     * @Route("/article", methods={"GET", "POST"}, name="article")
     *
     */
    public function newArticle(Request $request, ArticleRepository $articles, Article $article = null, ObjectManager $em) : Response
    {
        if (!$article) {
            $article = new Article();
        }

        // On Instancie le formulaire
        $form = $this->createForm(ArticleType::class, $article);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // On prépare l'objet à persister
            $article->setCreatedAt(new \DateTime());
            $article->setUser($this->getUser());
            $article->setReserv($article);

            $em->persist($article);
            $em->flush();
            //dump($article);


            $this->addFlash('success', 'created_successfully');

            return $this->redirectToRoute('article');
        }
        $userArticles = $articles->findBy(['user' => $this->getUser()]);

        return $this->render('article/edit_article.html.twig', [
            'article' => $article,
            'form' => $form->createView(),
            'articles' => $userArticles,
        ]);
    }

    /**
     * Displays a form to edit an existing Article entity.
     *
     * @Route("/article/{id<\d+>}/edit",methods={"GET", "POST"}, name="article_edit")
     *
     */
    public function editArticle(Request $request, ArticleRepository $articles, Article $article, ObjectManager $em) : Response
    {
        $form = $this->createForm(ArticleType::class, $article);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();

            $this->addFlash('success', 'updated_successfully');

            return $this->redirectToRoute('article');
        }
        $userArticles = $articles->findBy(['user' => $this->getUser()]);

        return $this->render('article/edit_article.html.twig', [
            'article' => $article,
            'form' => $form->createView(),
            'articles' => $userArticles,
        ]);
    }

    /**
     * Deletes a Article entity.
     *
     * @Route("/article/{id}/delete", methods={"GET", "POST"}, name="article_delete")
     *
     */
    public function deleteArticle(Article $article, ObjectManager $em) : Response
    {
        $em->remove($article);
        $em->flush();

        $this->addFlash('success', 'deleted_successfully');

        return $this->redirectToRoute('article');
    }

    /**
     * Creates a new Serial entity.
     *
     * @Route("/serial", methods={"GET", "POST"}, name="serial")
     *
     */
    public function newSerial(Request $request, SerialRepository $serials, Serial $serial = null, ObjectManager $em) : Response
    {
        if (!$serial) {
            $serial = new Serial();
        }

        // On Instancie le formulaire
        $form = $this->createForm(SerialType::class, $serial);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // On prépare l'objet à persister
            $serial->setCreatedAt(new \DateTime());
            $serial->setUser($this->getUser());

            $em->persist($serial);
            $em->flush();

            $this->addFlash('success', 'created_successfully');

            return $this->redirectToRoute('serial');
        }
        $userSerials = $serials->findBy(['user' => $this->getUser()]);

        return $this->render('article/edit_serial.html.twig', [
            'serial' => $serial,
            'form' => $form->createView(),
            'serials' => $userSerials,
        ]);
    }

    /**
     * Displays a form to edit an existing Unity entity.
     *
     * @Route("/serial/{id<\d+>}/edit",methods={"GET", "POST"}, name="serial_edit")
     *
     */
    public function editSerial(Request $request, SerialRepository $serials, Serial $serial, ObjectManager $em) : Response
    {
        $form = $this->createForm(SerialType::class, $serial);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();

            $this->addFlash('success', 'updated_successfully');

            return $this->redirectToRoute('serial');
        }
        $userSerials = $serials->findBy(['user' => $this->getUser()]);

        return $this->render('article/edit_serial.html.twig', [
            'serial' => $serial,
            'form' => $form->createView(),
            'serials' => $userSerials,
        ]);
    }

    /**
     * Deletes a Serial entity.
     *
     * @Route("/serial/{id}/delete", methods={"GET", "POST"}, name="serial_delete")
     *
     */
    public function deleteSerial(Serial $serial, ObjectManager $em) : Response
    {
        $em->remove($serial);
        $em->flush();

        $this->addFlash('success', 'deleted_successfully');

        return $this->redirectToRoute('serial');
    }
}
