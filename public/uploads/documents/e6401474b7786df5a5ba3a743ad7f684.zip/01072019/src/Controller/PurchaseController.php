<?php

namespace App\Controller;

use App\Entity\Article;
use App\Entity\SupplyRequest;
use App\Entity\SupplyRequestArticle;
use App\Form\SupplyRequestType;
use App\Form\SupplyRequestArticleType;
use App\Repository\SupplyRequestRepository;
use App\Repository\SupplyRequestArticleRepository;

use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Controller used to manage Purchase.
 *
 * @author Hervé Marcel Jiogue Tadie <fastochehost@gmail.com>
 * @author My Team <>
 */
class PurchaseController extends AbstractController
{
    /**
     * @Route("/purchase", name="purchase")
     */
    public function index()
    {
        return $this->render('purchase/index.html.twig', [
            'controller_name' => 'PurchaseController',
        ]);
    }

    /**
     * Creates a new Supply request entity.
     *
     * @Route("{_locale}/supply-request", methods={"GET", "POST"}, name="supply_request")
     *
     */
    public function newSupplyRequest(Request $request, SupplyRequestRepository $suppliesRequest, SupplyRequest $supplyRequest = null, ObjectManager $em): Response
    {
        if(!$supplyRequest){$supplyRequest = new SupplyRequest();}

        // On Instancie le formulaire
        $form = $this->createForm(SupplyRequestType::class, $supplyRequest);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // On prépare l'objet à persister
            $supplyRequest->setCreatedAt(new\DateTime());
            $supplyRequest->setUser($this->getUser());

            $em->persist($supplyRequest);
            $em->flush();

            $this->addFlash('success', 'created_successfully');

            return $this->redirectToRoute('supply_request');
        }
        $userSuppliesRequest = $suppliesRequest->findBy([], ['id' => 'DESC']);

        return $this->render('purchase/edit_supply_request.html.twig', [
            'supplyrequest' => $supplyRequest,
            'form' => $form->createView(),
            'suppliesRequest' => $userSuppliesRequest,
        ]);
    }

    /**
     * Displays a form to edit an existing request entity.
     *
     * @Route("/supply-request/{id<\d+>}/edit", methods={"GET", "POST"}, name="supply_request_edit")
     *
     */
    public function editSupplyRequest(Request $request, SupplyRequest $supplyRequest, ObjectManager $em): Response
    {
        $form = $this->createForm(SupplyRequestType::class, $supplyRequest);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();

            $this->addFlash('success', 'updated_successfully');

            return $this->redirectToRoute('supply_request');
        }

        return $this->render('purchase/edit_supply_request.html.twig', [
            'supplyrequest' => $supplyRequest,
            'form' => $form->createView(),
        ]);
    }

    /**
     * Deletes a supply request entity.
     *
     * @Route("/supply-request/{id}/delete", methods={"GET", "POST"}, name="supply_request_delete")
     *
     */
    public function deleteSupplyRequest(Request $request, SupplyRequest $supplyRequest, ObjectManager $em): Response
    {
        $em->remove($supplyRequest);
        $em->flush();

        $this->addFlash('success', 'deleted_successfully');

        return $this->redirectToRoute('supply_request');
    }


    /**
     * Displays a form to edit an existing Item type entity.
     *
     * @Route("/supply-request/{id<\d+>}/valid",methods={"GET", "POST"}, name="supply_request_valid")
     *
     */
    public function validSupplyRequest(Request $request, SupplyRequest $supplyRequest, ObjectManager $em): Response
    {
        $supplyRequest->setIsValid(true);
        $em->flush();

        $this->addFlash('success', 'valid_successfully');

        return $this->redirectToRoute('supply_request');
    }

    /**
     * Displays a form to edit an existing Item type entity.
     *
     * @Route("/supply-request/{id<\d+>}/unvalid", methods={"GET", "POST"}, name="supply_request_reject")
     *
     */
    public function rejectSupplyRequest(Request $request, SupplyRequest $supplyRequest, ObjectManager $em): Response
    {
        $supplyRequest->setIsValid(false);
        $em->flush();

        $this->addFlash('success', 'successfully');

        return $this->redirectToRoute('supply_request');
    }

    /**
     * Displays a form to edit an existing Item type entity.
     *
     * @Route("/supply-request/{id<\d+>}/cancel", methods={"GET", "POST"}, name="supply_request_cancel")
     *
     */
    /*public function cancelSupplyRequest(Request $request, SupplyRequest $supplyRequest, ObjectManager $em): Response
    {
        $supplyRequest->setIsValid(NULL);
        $em->flush();

        $this->addFlash('success', 'successfully');

        return $this->redirectToRoute('supply_request');
    }*/

    /**
     * Lists all Supply request Articles.
     *
     * @Route("/supply-request-article", methods={"GET"}, name="supply_request_article")
     *
     */
    /*public function showSupplyRequestArticle(SupplyRequestArticleRepository $supplyRequestArticles): Response
    {
        $userSupplyRequestArticles = $supplyRequestArticles->findBy([], ['id' => 'DESC']);

        return $this->render('purchase/show_supply_request_article.html.twig', ['supplyRequestArticles' => $userSupplyRequestArticles]);
    }*/

    /**
     * Displays a form to edit an existing Supply request entity.
     *
     * @Route("/supply-request/{id<\d+>}/cart", methods={"GET", "POST"}, name="supply_request_cart")
     *
     */
    public function cartSupplyRequest(Request $request, SupplyRequest $supplyRequest, SupplyRequestArticleRepository $supplyRequestArticles, SupplyRequestArticle $supplyRequestArticle = null, ObjectManager $em): Response
    {
        if(!$supplyRequestArticle) {
            $supplyRequestArticle = new SupplyRequestArticle();

            $form = $this->createFormBuilder($supplyRequestArticle)
                ->add('quantity', IntegerType::class, array(
                    'attr' => array(
                        'class' => 'form-control',
                        'placeholder' => 'quantity',
                    ),
                    'trim' => true,
                    'required' => true,
                ))
                ->add('article', EntityType::class, array(
                    'class' => Article::class,
                    'expanded' => false,
                    'choice_label' => 'reference',
                    'multiple' => false,
                    'placeholder' => 'Choose an article',
                    'attr' => array(
                        'class' => 'form-control select-search',
                    ),
                ))
                ->add('sr', TextType::class, array(
                    'attr' => array(
                        'class' => 'form-control',
                    ),
                    'trim' => true,
                    'data' => $supplyRequest->getId(),
                ))
                ->getForm();

            $form->handleRequest($request);
        }

        if ($form->isSubmitted() && $form->isValid()) {
            $supplyRequestArticle->setCreatedAt(new\DateTime());
            $supplyRequestArticle->setSupply($supplyRequest);

            $em->persist($supplyRequestArticle);
            $em->flush();

            $this->addFlash('success', 'updated_successfully');

            return $this->redirectToRoute('supply_request_cart', array('id' => $supplyRequest->getId()));
        }

        // repository pour l'affichage du tableau
        $userSupplyRequestArticles = $supplyRequestArticles->findBy(['supply' => $supplyRequest], ['id' => 'DESC']);

        // retour du formulaire et du tableau
        return $this->render('purchase/cart_supply_request.html.twig', [
            'supplyrequestarticle' => $supplyRequestArticle,
            'form' => $form->createView(),
            'supplyRequestArticles' => $userSupplyRequestArticles,
        ]);
    }

    /**
     * Displays a form to edit an existing Supply request article entity.
     *
     * @Route("/supply-request-cart/{id<\d+>}/edit", methods={"GET", "POST"}, name="supply_request_cart_edit")
     *
     */
    public function editArticleInSupplyRequest(Request $request, SupplyRequestArticleRepository $supplyRequestArticles, SupplyRequestArticle $supplyRequestArticle, ObjectManager $em): Response
    {
        $form = $this->createForm(SupplyRequestArticleType::class, $supplyRequestArticle);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();

            $this->addFlash('success', 'updated_successfully');

            //return $this->redirectToRoute('supply_request_cart', array('id' => $supplyRequest->getId()));
        }

        //$userSupplyRequestArticles = $supplyRequestArticles->findBy(['supply' => $supplyRequest], ['id' => 'DESC']);

        return $this->render('purchase/cart_supply_request.html.twig', [
            'supplyrequestarticle' => $supplyRequestArticle,
            'form' => $form->createView(),
            /*'supplyRequestArticles' => $userSupplyRequestArticles,*/
        ]);
    }

    /**
     * Deletes a supply request article entity.
     *
     * @Route("/supply-request-cart/{id}/delete", methods={"GET", "POST"}, name="supply_request_cart_delete")
     *
     */
    public function deleteArticleInSupplyRequest(Request $request, SupplyRequestArticle $supplyRequestArticle, ObjectManager $em): Response
    {
        $em->remove($supplyRequestArticle);
        $em->flush();

        $this->addFlash('success', 'deleted_successfully');

        return $this->redirectToRoute('supply_request_cart');
    }
}
