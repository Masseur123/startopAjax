<?php

namespace App\Controller\Transit;

use App\Entity\Log;
use App\Entity\LoadingLog;
use App\Entity\LogProcurement;

use App\Form\LogProcurementType;
use App\Form\LogType;
use App\Form\LoadingLogType;

use App\Repository\LogProcurementRepository;
use App\Repository\LogRepository;
use App\Repository\LoadingLogRepository;

use Symfony\Component\Form\Extension\Core\Type\SubmitType;

use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Repository\UserRepository;

/**
 * Controller used to manage transit log.
 *
 * @author Hervé Marcel Jiogue Tadie <fastochehost@gmail.com>
 * @author My Team <>
 */
class TransitLogController extends AbstractController
{
    /*
     * Creates a new Transit log procurement entity.
     *
     * @Route("{_locale}/log-procurement", methods={"GET", "POST"}, name="log_procurement")
     *
    public function newLogProcurement(Request $request, LogProcurementRepository $logProcurements, ObjectManager $em, UserRepository $user): Response
    {
        $logProcurement = new LogProcurement();

        // On Instancie le formulaire
        $form = $this->createForm(LogProcurementType::class, $logProcurement);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // Get Branch 
            $branch = $user->findOneBy(['id' => $this->getUser()])->getBranch();

            // On prépare l'objet à persister
            $logProcurement->setCreatedAt(new \DateTime());
            $logProcurement->setUser($this->getUser());
            $logProcurement->setBranch($branch);

            $em->persist($logProcurement);
            $em->flush();

            $this->addFlash('success', 'Success!');

            return $this->redirectToRoute('log_procurement');
        }
        $userLogProcurements = $logProcurements->findBy([], ['id' => 'DESC']);

        return $this->render('transit_log/edit_log-procurement.html.twig', [
            'form' => $form->createView(),
            'logProcurements' => $userLogProcurements,
        ]);
    }
     */

    /*
     * Displays a form to edit an existing transit log procurement entity.
     *
     * @Route("{_locale}/log-procurement/{id<\d+>}/edit",methods={"GET", "POST"}, name="log_procurement_edit")
     *
    public function editLogProcurement(Request $request, LogProcurementRepository $logProcurements, LogProcurement $logProcurement, ObjectManager $em): Response
    {
        $form = $this->createForm(LogProcurementType::class, $logProcurement);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();

            $this->addFlash('success', 'Success!');

            return $this->redirectToRoute('log_procurement');
        }
        $userLogProcurements = $logProcurements->findBy([], ['id' => 'DESC']);

        return $this->render('transit_log/edit_log-procurement.html.twig', [
            'form' => $form->createView(),
            'logProcurements' => $userLogProcurements,
        ]);
    }
     */

      /**
     * Lists all LogProcurement .
     *
     *
     * @Route("{_locale}/log-procurement", methods={"GET"}, name="log_procurement")
     *
     */
    public function showLogProcurement(LogProcurementRepository $logProcurements): Response
    {
        $userLogProcurements = $logProcurements->findBy(['user' => $this->getUser()], ['createdAt' => 'DESC']);

        return $this->render('transit_log/show_log-procurement.html.twig', ['logProcurements' => $userLogProcurements]);
    }

    /**
     * Creates a new Log Procurement  entity.
     *
     * @Route("{_locale}/log-procurements/new", methods={"GET", "POST"}, name="log_procurement_new")
     *
     */
    public function newLogProcurement(Request $request, LogProcurement $logProcurement = null, ObjectManager $em, UserRepository $user): Response
    {
        if(!$logProcurement){$logProcurement = new LogProcurement();}

        // On Instancie le formulaire
        $form = $this->createForm(LogProcurementType::class, $logProcurement)
            ->add('saveAndCreateNew', SubmitType::class);

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            $branch = $user->findOneBy(['id' => $this->getUser()])->getBranch();

            // On prépare l'objet à persister
            $logProcurement->setCreatedAt(new\DateTime());
            $logProcurement->setUser($this->getUser());
            $logProcurement->setBranch($branch);

            $em->persist($logProcurement);
            $em->flush();

            $this->addFlash('success', 'log.Procurements.created_successfully');

            if ($form->get('saveAndCreateNew')->isClicked()) {
                return $this->redirectToRoute('log_procurement_new');
            }

            return $this->redirectToRoute('log_procurement');
        }

        return $this->render('transit_log/edit_log-procurement.html.twig', [
            'logProcurement' => $logProcurement,
            'form' => $form->createView(),
        ]);
    }

    /**
     * Displays a form to edit an existing Log Procurement  entity.
     *
     * @Route("{_locale}/log-procurement/{id<\d+>}/edit",methods={"GET", "POST"}, name="log_procurement_edit")
     *
     */
    public function editLogProcurement(Request $request, LogProcurement $logProcurement, ObjectManager $em): Response
    {
        $form = $this->createForm(LogProcurementType::class, $logProcurement)
        ->add('saveAndCreateNew', SubmitType::class);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();

            $this->addFlash('success', 'log.procurement.updated_successfully');
			
			if ($form->get('saveAndCreateNew')->isClicked()) {
                return $this->redirectToRoute('log_procurement_new');
            }

            return $this->redirectToRoute('log_procurement');
        }

        return $this->render('transit_log/edit_log-procurement.html.twig', [
            'logProcurement' => $logProcurement,
            'form' => $form->createView(),
        ]);
    }

    /**
     * Deletes a Transit log procurement entity.
     *
     * @Route("/log-procurement/{id}/delete", methods={"GET", "POST"}, name="log_procurement_delete")
     *
     */
    public function deleteLogProcurement(LogProcurement $logProcurement, ObjectManager $em): Response
    {
        $em->remove($logProcurement);
        $em->flush();

        $this->addFlash('success', 'Success!');

        return $this->redirectToRoute('log_procurement');
    }

    /**
     * Lists all Log .
     *
     *
     * @Route("{_locale}/log", methods={"GET"}, name="log")
     *
     */
    public function showLog(LogRepository $logs): Response
    {
        $userLogs = $logs->findBy(['user' => $this->getUser()], ['createdAt' => 'DESC']);

        return $this->render('transit_log/show_log.html.twig', ['logs' => $userLogs]);
    }

    /**
     * Creates a new Log   entity.
     *
     * @Route("{_locale}/log/new", methods={"GET", "POST"}, name="log_new")
     *
     */
    public function newLog(Request $request, Log $log = null, ObjectManager $em, UserRepository $user): Response
    {
        if(!$log){$log = new Log();}

        // On Instancie le formulaire
        $form = $this->createForm(LogType::class, $log)
            ->add('saveAndCreateNew', SubmitType::class);

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            $branch = $user->findOneBy(['id' => $this->getUser()])->getBranch();

            // On prépare l'objet à persister
            $log->setCreatedAt(new\DateTime());
            $log->setUser($this->getUser());
            $log->setBranch($branch);

            $em->persist($log);
            $em->flush();

            $this->addFlash('success', 'log.created_successfully');

            if ($form->get('saveAndCreateNew')->isClicked()) {
                return $this->redirectToRoute('log_new');
            }

            return $this->redirectToRoute('log');
        }

        return $this->render('transit_log/edit_log.html.twig', [
            'log' => $log,
            'form' => $form->createView(),
        ]);
    }

    /**
     * Displays a form to edit an existing Log  entity.
     *
     * @Route("{_locale}/log/{id<\d+>}/edit",methods={"GET", "POST"}, name="log_edit")
     *
     */
    public function editLog(Request $request, Log $log, ObjectManager $em): Response
    {
        $form = $this->createForm(LogType::class, $log)
        ->add('saveAndCreateNew', SubmitType::class);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();

            $this->addFlash('success', 'log.updated_successfully');
			
			if ($form->get('saveAndCreateNew')->isClicked()) {
                return $this->redirectToRoute('log_new');
            }

            return $this->redirectToRoute('log');
        }

        return $this->render('transit_log/edit_log.html.twig', [
            'log' => $log,
            'form' => $form->createView(),
        ]);
    }

    /**
     * Deletes a log entity.
     *
     * @Route("/log/{id}/delete", methods={"GET", "POST"}, name="log_delete")
     *
     */
    public function deleteLog(Log $log, ObjectManager $em): Response
    {
        $em->remove($log);
        $em->flush();

        $this->addFlash('success', 'Success!');

        return $this->redirectToRoute('log');
    }
	
	/**
     * Lists all Log Loading.
     *
     *
     * @Route("{_locale}/log/loading", methods={"GET"}, name="loading_log")
     *
     */
    public function showLogLoading(LoadingLogRepository $loadings): Response
    {
        // $userLoadings = $loadings->findBy(['user' => $this->getUser()]);
		$userLoadings = $loadings->findBy([], ['id' => 'DESC']);

        return $this->render('transit_log/show_log_loading.html.twig', ['loadings' => $userLoadings]);
    }

    /**
     * Creates a new loading   entity.
     *
     * @Route("{_locale}/log/loading/new", methods={"GET", "POST"}, name="loading_log_new")
     *
     */
    public function newLogLoading(Request $request, LoadingLog $loading = null, ObjectManager $em, UserRepository $user): Response
    {
        if(!$loading){$loading = new LoadingLog();}

        // On Instancie le formulaire
        $form = $this->createForm(LoadingLogType::class, $loading)
            ->add('saveAndCreateNew', SubmitType::class);

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            $branch = $user->findOneBy(['id' => $this->getUser()])->getBranch();

            // On prépare l'objet à persister
            $loading->setUser($this->getUser());
            $loading->setBranch($branch);

            $em->persist($loading);
            $em->flush();

            $this->addFlash('success', 'loading.created_successfully');

            if ($form->get('saveAndCreateNew')->isClicked()) {
                return $this->redirectToRoute('loading_log_new');
            }

            return $this->redirectToRoute('loading_log');
        }

        return $this->render('transit_log/edit_log_loading.html.twig', [
            'loading' => $loading,
            'form' => $form->createView(),
        ]);
    }

    /**
     * Displays a form to edit an existing loading entity.
     *
     * @Route("{_locale}/log/loading/{id<\d+>}/edit",methods={"GET", "POST"}, name="loading_log_edit")
     *
     */
    public function editLogLoading(Request $request, LoadingLog $loading, ObjectManager $em): Response
    {
        $form = $this->createForm(LoadingLogType::class, $loading)
                                 ->add('saveAndCreateNew', SubmitType::class);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();

            $this->addFlash('success', 'loading.updated_successfully');
			
			if ($form->get('saveAndCreateNew')->isClicked()) {
                return $this->redirectToRoute('loading_log_new');
            }

            return $this->redirectToRoute('loading_log');
        }

        return $this->render('transit_log/edit_log_loading.html.twig', [
            'loading' => $loading,
            'form' => $form->createView(),
        ]);
    }

    /**
     * Deletes a Loading entity.
     *
     * @Route("/log/loading/{id}/delete", methods={"GET", "POST"}, name="loading_log_delete")
     *
     */
    public function deleteLoading(LoadingLog $loading, ObjectManager $em): Response
    {
        $em->remove($loading);
        $em->flush();

        $this->addFlash('success', 'Success!');

        return $this->redirectToRoute('loading_log');
    }
}
