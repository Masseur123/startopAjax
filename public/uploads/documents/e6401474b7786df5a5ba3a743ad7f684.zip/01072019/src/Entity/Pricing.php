<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\PricingRepository")
 * @ORM\Table(name="ho_pricing")
 *
 * @author Jiogue Tadie Hervé Marcel <fastochehost@gmail.com>
 */
class Pricing
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="decimal", precision=12, scale=2)
     */
    private $price;

    /**
     * @ORM\Column(type="datetime")
     */
    private $createdAt;

    /**
     * @ORM\Column(type="boolean")
     */
    private $is_enabled;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Housing", inversedBy="pricings")
     */
    private $housing;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\HousingType", inversedBy="pricings")
     */
    private $housingtype;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\PricingPlan", inversedBy="pricings")
     */
    private $pricingplan;

    /**
     * @ORM\Column(type="decimal", nullable=true)
     */
    private $p_min;

    /**
     * @ORM\Column(type="decimal", nullable=true)
     */
    private $p_max;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    private $ordering;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\User")
     */
    private $user;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Branch")
     */
    private $branch;

    public function getId()
    {
        return $this->id;
    }

    public function getPrice()
    {
        return $this->price;
    }

    public function setPrice($price): self
    {
        $this->price = $price;

        return $this;
    }

    public function getCreatedAt(): ?\DateTimeInterface
    {
        return $this->createdAt;
    }

    public function setCreatedAt(\DateTimeInterface $createdAt): self
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    public function getIsEnabled(): ?bool
    {
        return $this->is_enabled;
    }

    public function setIsEnabled(bool $is_enabled): self
    {
        $this->is_enabled = $is_enabled;

        return $this;
    }

    public function getHousing(): ?Housing
    {
        return $this->housing;
    }

    public function setHousing(?Housing $housing): self
    {
        $this->housing = $housing;

        return $this;
    }

    public function getHousingtype(): ?HousingType
    {
        return $this->housingtype;
    }

    public function setHousingtype(?HousingType $housingtype): self
    {
        $this->housingtype = $housingtype;

        return $this;
    }

    public function getPricingplan(): ?PricingPlan
    {
        return $this->pricingplan;
    }

    public function setPricingplan(?PricingPlan $pricingplan): self
    {
        $this->pricingplan = $pricingplan;

        return $this;
    }

    public function getPMin(): ?bool
    {
        return $this->p_min;
    }

    public function setPMin(?bool $p_min): self
    {
        $this->p_min = $p_min;

        return $this;
    }

    public function getPMax(): ?bool
    {
        return $this->p_max;
    }

    public function setPMax(?bool $p_max): self
    {
        $this->p_max = $p_max;

        return $this;
    }

    public function getOrdering(): ?int
    {
        return $this->ordering;
    }

    public function setOrdering(?int $ordering): self
    {
        $this->ordering = $ordering;

        return $this;
    }

    public function getUser(): ?User
    {
        return $this->user;
    }

    public function setUser(?User $user): self
    {
        $this->user = $user;

        return $this;
    }

    public function getBranch(): ?Branch
    {
        return $this->branch;
    }

    public function setBranch(?Branch $branch): self
    {
        $this->branch = $branch;

        return $this;
    }
}
