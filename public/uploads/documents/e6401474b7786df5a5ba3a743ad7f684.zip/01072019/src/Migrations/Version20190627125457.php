<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20190627125457 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('CREATE TABLE loading_log (id INT AUTO_INCREMENT NOT NULL, container_id INT DEFAULT NULL, user_id INT NOT NULL, wood_id INT NOT NULL, branch_id INT NOT NULL, transit_id INT DEFAULT NULL, reference VARCHAR(255) DEFAULT NULL, load_at DATETIME NOT NULL, nbrofpiece INT NOT NULL, volume DOUBLE PRECISION DEFAULT NULL, INDEX IDX_EACEB32ABC21F742 (container_id), INDEX IDX_EACEB32AA76ED395 (user_id), INDEX IDX_EACEB32A7B2710BE (wood_id), INDEX IDX_EACEB32ADCD6CC49 (branch_id), INDEX IDX_EACEB32A617C70E0 (transit_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('ALTER TABLE loading_log ADD CONSTRAINT FK_EACEB32ABC21F742 FOREIGN KEY (container_id) REFERENCES tra_container (id)');
        $this->addSql('ALTER TABLE loading_log ADD CONSTRAINT FK_EACEB32AA76ED395 FOREIGN KEY (user_id) REFERENCES se_user (id)');
        $this->addSql('ALTER TABLE loading_log ADD CONSTRAINT FK_EACEB32A7B2710BE FOREIGN KEY (wood_id) REFERENCES tra_wood (id)');
        $this->addSql('ALTER TABLE loading_log ADD CONSTRAINT FK_EACEB32ADCD6CC49 FOREIGN KEY (branch_id) REFERENCES se_branch (id)');
        $this->addSql('ALTER TABLE loading_log ADD CONSTRAINT FK_EACEB32A617C70E0 FOREIGN KEY (transit_id) REFERENCES tra_transit (id)');
        $this->addSql('ALTER TABLE act_piece CHANGE account_id account_id INT DEFAULT NULL');
        $this->addSql('DROP INDEX UNIQ_11EBD0E2B36786B ON act_account');
        $this->addSql('ALTER TABLE se_role ADD CONSTRAINT FK_D4BB864DCCD7E912 FOREIGN KEY (menu_id) REFERENCES se_role (id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('DROP TABLE loading_log');
        $this->addSql('CREATE UNIQUE INDEX UNIQ_11EBD0E2B36786B ON act_account (title)');
        $this->addSql('ALTER TABLE act_piece CHANGE account_id account_id INT NOT NULL');
        $this->addSql('ALTER TABLE se_role DROP FOREIGN KEY FK_D4BB864DCCD7E912');
    }
}
