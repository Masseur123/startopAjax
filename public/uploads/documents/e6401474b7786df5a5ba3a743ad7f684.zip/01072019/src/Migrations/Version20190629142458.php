<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20190629142458 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE ho_housing_option DROP FOREIGN KEY FK_212A9C3E3243BB18');
        $this->addSql('DROP INDEX IDX_212A9C3E3243BB18 ON ho_housing_option');
        $this->addSql('ALTER TABLE ho_housing_option CHANGE hotel_id branch_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_housing_option ADD CONSTRAINT FK_212A9C3EDCD6CC49 FOREIGN KEY (branch_id) REFERENCES se_branch (id)');
        $this->addSql('CREATE INDEX IDX_212A9C3EDCD6CC49 ON ho_housing_option (branch_id)');
        $this->addSql('ALTER TABLE ho_housing_type DROP FOREIGN KEY FK_8CEEF9393243BB18');
        $this->addSql('DROP INDEX IDX_8CEEF9393243BB18 ON ho_housing_type');
        $this->addSql('ALTER TABLE ho_housing_type CHANGE hotel_id branch_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_housing_type ADD CONSTRAINT FK_8CEEF939DCD6CC49 FOREIGN KEY (branch_id) REFERENCES se_branch (id)');
        $this->addSql('CREATE INDEX IDX_8CEEF939DCD6CC49 ON ho_housing_type (branch_id)');
        $this->addSql('ALTER TABLE ho_stay_type DROP FOREIGN KEY FK_29B9C8AF3243BB18');
        $this->addSql('DROP INDEX IDX_29B9C8AF3243BB18 ON ho_stay_type');
        $this->addSql('ALTER TABLE ho_stay_type DROP is_enabled, CHANGE hotel_id branch_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_stay_type ADD CONSTRAINT FK_29B9C8AFDCD6CC49 FOREIGN KEY (branch_id) REFERENCES se_branch (id)');
        $this->addSql('CREATE INDEX IDX_29B9C8AFDCD6CC49 ON ho_stay_type (branch_id)');
        $this->addSql('ALTER TABLE ho_meal DROP FOREIGN KEY FK_D96669E93243BB18');
        $this->addSql('DROP INDEX IDX_D96669E93243BB18 ON ho_meal');
        $this->addSql('ALTER TABLE ho_meal CHANGE hotel_id branch_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_meal ADD CONSTRAINT FK_D96669E9DCD6CC49 FOREIGN KEY (branch_id) REFERENCES se_branch (id)');
        $this->addSql('CREATE INDEX IDX_D96669E9DCD6CC49 ON ho_meal (branch_id)');
        $this->addSql('ALTER TABLE ho_season DROP FOREIGN KEY FK_9CC2E6513243BB18');
        $this->addSql('DROP INDEX IDX_9CC2E6513243BB18 ON ho_season');
        $this->addSql('ALTER TABLE ho_season DROP hotel_id, DROP is_enabled');
        $this->addSql('ALTER TABLE ho_housing DROP FOREIGN KEY FK_488B1E503243BB18');
        $this->addSql('DROP INDEX IDX_488B1E503243BB18 ON ho_housing');
        $this->addSql('ALTER TABLE ho_housing CHANGE hotel_id branch_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_housing ADD CONSTRAINT FK_488B1E50DCD6CC49 FOREIGN KEY (branch_id) REFERENCES se_branch (id)');
        $this->addSql('CREATE INDEX IDX_488B1E50DCD6CC49 ON ho_housing (branch_id)');
        $this->addSql('ALTER TABLE ho_tag_category DROP FOREIGN KEY FK_E57FF76D3243BB18');
        $this->addSql('DROP INDEX IDX_E57FF76D3243BB18 ON ho_tag_category');
        $this->addSql('ALTER TABLE ho_tag_category DROP is_enabled, CHANGE hotel_id branch_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_tag_category ADD CONSTRAINT FK_E57FF76DDCD6CC49 FOREIGN KEY (branch_id) REFERENCES se_branch (id)');
        $this->addSql('CREATE INDEX IDX_E57FF76DDCD6CC49 ON ho_tag_category (branch_id)');
        $this->addSql('ALTER TABLE ho_tag DROP FOREIGN KEY FK_21A1BD6D3243BB18');
        $this->addSql('DROP INDEX IDX_21A1BD6D3243BB18 ON ho_tag');
        $this->addSql('ALTER TABLE ho_tag DROP is_enabled, CHANGE hotel_id branch_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_tag ADD CONSTRAINT FK_21A1BD6DDCD6CC49 FOREIGN KEY (branch_id) REFERENCES se_branch (id)');
        $this->addSql('CREATE INDEX IDX_21A1BD6DDCD6CC49 ON ho_tag (branch_id)');
        $this->addSql('ALTER TABLE ho_equipment DROP FOREIGN KEY FK_EB89A28F3243BB18');
        $this->addSql('DROP INDEX IDX_EB89A28F3243BB18 ON ho_equipment');
        $this->addSql('ALTER TABLE ho_equipment DROP is_enabled, CHANGE hotel_id branch_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_equipment ADD CONSTRAINT FK_EB89A28FDCD6CC49 FOREIGN KEY (branch_id) REFERENCES se_branch (id)');
        $this->addSql('CREATE INDEX IDX_EB89A28FDCD6CC49 ON ho_equipment (branch_id)');
        $this->addSql('ALTER TABLE ho_equipment_category DROP FOREIGN KEY FK_180537AE3243BB18');
        $this->addSql('DROP INDEX IDX_180537AE3243BB18 ON ho_equipment_category');
        $this->addSql('ALTER TABLE ho_equipment_category DROP name, DROP is_enabled, CHANGE hotel_id branch_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_equipment_category ADD CONSTRAINT FK_180537AEDCD6CC49 FOREIGN KEY (branch_id) REFERENCES se_branch (id)');
        $this->addSql('CREATE INDEX IDX_180537AEDCD6CC49 ON ho_equipment_category (branch_id)');
        $this->addSql('ALTER TABLE ho_extra DROP FOREIGN KEY FK_6D1718313243BB18');
        $this->addSql('DROP INDEX IDX_6D1718313243BB18 ON ho_extra');
        $this->addSql('ALTER TABLE ho_extra CHANGE hotel_id branch_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_extra ADD CONSTRAINT FK_6D171831DCD6CC49 FOREIGN KEY (branch_id) REFERENCES se_branch (id)');
        $this->addSql('CREATE INDEX IDX_6D171831DCD6CC49 ON ho_extra (branch_id)');
        $this->addSql('ALTER TABLE ho_extra_category DROP FOREIGN KEY FK_A88B1C6A3243BB18');
        $this->addSql('DROP INDEX IDX_A88B1C6A3243BB18 ON ho_extra_category');
        $this->addSql('ALTER TABLE ho_extra_category DROP is_enabled, DROP name, CHANGE hotel_id branch_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_extra_category ADD CONSTRAINT FK_A88B1C6ADCD6CC49 FOREIGN KEY (branch_id) REFERENCES se_branch (id)');
        $this->addSql('CREATE INDEX IDX_A88B1C6ADCD6CC49 ON ho_extra_category (branch_id)');
        $this->addSql('ALTER TABLE ho_pricing_plan DROP FOREIGN KEY FK_234EC4B43243BB18');
        $this->addSql('DROP INDEX IDX_234EC4B43243BB18 ON ho_pricing_plan');
        $this->addSql('ALTER TABLE ho_pricing_plan DROP is_enabled, CHANGE hotel_id branch_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_pricing_plan ADD CONSTRAINT FK_234EC4B4DCD6CC49 FOREIGN KEY (branch_id) REFERENCES se_branch (id)');
        $this->addSql('CREATE INDEX IDX_234EC4B4DCD6CC49 ON ho_pricing_plan (branch_id)');
        $this->addSql('ALTER TABLE ho_pricing DROP FOREIGN KEY FK_56FBF0A03243BB18');
        $this->addSql('DROP INDEX IDX_56FBF0A03243BB18 ON ho_pricing');
        $this->addSql('ALTER TABLE ho_pricing CHANGE p_min p_min NUMERIC(10, 0) DEFAULT NULL, CHANGE p_max p_max NUMERIC(10, 0) DEFAULT NULL, CHANGE hotel_id branch_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_pricing ADD CONSTRAINT FK_56FBF0A0DCD6CC49 FOREIGN KEY (branch_id) REFERENCES se_branch (id)');
        $this->addSql('CREATE INDEX IDX_56FBF0A0DCD6CC49 ON ho_pricing (branch_id)');
        $this->addSql('ALTER TABLE ho_source_of_reservation DROP is_enabled');
        $this->addSql('ALTER TABLE ho_reservation_group DROP FOREIGN KEY FK_10185C1F3243BB18');
        $this->addSql('DROP INDEX IDX_10185C1F3243BB18 ON ho_reservation_group');
        $this->addSql('ALTER TABLE ho_reservation_group DROP is_enabled, CHANGE hotel_id branch_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_reservation_group ADD CONSTRAINT FK_10185C1FDCD6CC49 FOREIGN KEY (branch_id) REFERENCES se_branch (id)');
        $this->addSql('CREATE INDEX IDX_10185C1FDCD6CC49 ON ho_reservation_group (branch_id)');
        $this->addSql('ALTER TABLE ho_reservation DROP FOREIGN KEY FK_201CDA773243BB18');
        $this->addSql('DROP INDEX IDX_201CDA773243BB18 ON ho_reservation');
        $this->addSql('ALTER TABLE ho_reservation CHANGE hotel_id branch_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_reservation ADD CONSTRAINT FK_201CDA77DCD6CC49 FOREIGN KEY (branch_id) REFERENCES se_branch (id)');
        $this->addSql('CREATE INDEX IDX_201CDA77DCD6CC49 ON ho_reservation (branch_id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE ho_equipment DROP FOREIGN KEY FK_EB89A28FDCD6CC49');
        $this->addSql('DROP INDEX IDX_EB89A28FDCD6CC49 ON ho_equipment');
        $this->addSql('ALTER TABLE ho_equipment ADD is_enabled TINYINT(1) NOT NULL, CHANGE branch_id hotel_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_equipment ADD CONSTRAINT FK_EB89A28F3243BB18 FOREIGN KEY (hotel_id) REFERENCES ho_hotel (id)');
        $this->addSql('CREATE INDEX IDX_EB89A28F3243BB18 ON ho_equipment (hotel_id)');
        $this->addSql('ALTER TABLE ho_equipment_category DROP FOREIGN KEY FK_180537AEDCD6CC49');
        $this->addSql('DROP INDEX IDX_180537AEDCD6CC49 ON ho_equipment_category');
        $this->addSql('ALTER TABLE ho_equipment_category ADD name VARCHAR(255) NOT NULL COLLATE utf8mb4_unicode_ci, ADD is_enabled TINYINT(1) NOT NULL, CHANGE branch_id hotel_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_equipment_category ADD CONSTRAINT FK_180537AE3243BB18 FOREIGN KEY (hotel_id) REFERENCES ho_hotel (id)');
        $this->addSql('CREATE INDEX IDX_180537AE3243BB18 ON ho_equipment_category (hotel_id)');
        $this->addSql('ALTER TABLE ho_extra DROP FOREIGN KEY FK_6D171831DCD6CC49');
        $this->addSql('DROP INDEX IDX_6D171831DCD6CC49 ON ho_extra');
        $this->addSql('ALTER TABLE ho_extra CHANGE branch_id hotel_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_extra ADD CONSTRAINT FK_6D1718313243BB18 FOREIGN KEY (hotel_id) REFERENCES ho_hotel (id)');
        $this->addSql('CREATE INDEX IDX_6D1718313243BB18 ON ho_extra (hotel_id)');
        $this->addSql('ALTER TABLE ho_extra_category DROP FOREIGN KEY FK_A88B1C6ADCD6CC49');
        $this->addSql('DROP INDEX IDX_A88B1C6ADCD6CC49 ON ho_extra_category');
        $this->addSql('ALTER TABLE ho_extra_category ADD is_enabled TINYINT(1) NOT NULL, ADD name VARCHAR(255) NOT NULL COLLATE utf8mb4_unicode_ci, CHANGE branch_id hotel_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_extra_category ADD CONSTRAINT FK_A88B1C6A3243BB18 FOREIGN KEY (hotel_id) REFERENCES ho_hotel (id)');
        $this->addSql('CREATE INDEX IDX_A88B1C6A3243BB18 ON ho_extra_category (hotel_id)');
        $this->addSql('ALTER TABLE ho_housing DROP FOREIGN KEY FK_488B1E50DCD6CC49');
        $this->addSql('DROP INDEX IDX_488B1E50DCD6CC49 ON ho_housing');
        $this->addSql('ALTER TABLE ho_housing CHANGE branch_id hotel_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_housing ADD CONSTRAINT FK_488B1E503243BB18 FOREIGN KEY (hotel_id) REFERENCES ho_hotel (id)');
        $this->addSql('CREATE INDEX IDX_488B1E503243BB18 ON ho_housing (hotel_id)');
        $this->addSql('ALTER TABLE ho_housing_option DROP FOREIGN KEY FK_212A9C3EDCD6CC49');
        $this->addSql('DROP INDEX IDX_212A9C3EDCD6CC49 ON ho_housing_option');
        $this->addSql('ALTER TABLE ho_housing_option CHANGE branch_id hotel_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_housing_option ADD CONSTRAINT FK_212A9C3E3243BB18 FOREIGN KEY (hotel_id) REFERENCES ho_hotel (id)');
        $this->addSql('CREATE INDEX IDX_212A9C3E3243BB18 ON ho_housing_option (hotel_id)');
        $this->addSql('ALTER TABLE ho_housing_type DROP FOREIGN KEY FK_8CEEF939DCD6CC49');
        $this->addSql('DROP INDEX IDX_8CEEF939DCD6CC49 ON ho_housing_type');
        $this->addSql('ALTER TABLE ho_housing_type CHANGE branch_id hotel_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_housing_type ADD CONSTRAINT FK_8CEEF9393243BB18 FOREIGN KEY (hotel_id) REFERENCES ho_hotel (id)');
        $this->addSql('CREATE INDEX IDX_8CEEF9393243BB18 ON ho_housing_type (hotel_id)');
        $this->addSql('ALTER TABLE ho_meal DROP FOREIGN KEY FK_D96669E9DCD6CC49');
        $this->addSql('DROP INDEX IDX_D96669E9DCD6CC49 ON ho_meal');
        $this->addSql('ALTER TABLE ho_meal CHANGE branch_id hotel_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_meal ADD CONSTRAINT FK_D96669E93243BB18 FOREIGN KEY (hotel_id) REFERENCES ho_hotel (id)');
        $this->addSql('CREATE INDEX IDX_D96669E93243BB18 ON ho_meal (hotel_id)');
        $this->addSql('ALTER TABLE ho_pricing DROP FOREIGN KEY FK_56FBF0A0DCD6CC49');
        $this->addSql('DROP INDEX IDX_56FBF0A0DCD6CC49 ON ho_pricing');
        $this->addSql('ALTER TABLE ho_pricing CHANGE p_min p_min TINYINT(1) DEFAULT NULL, CHANGE p_max p_max TINYINT(1) DEFAULT NULL, CHANGE branch_id hotel_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_pricing ADD CONSTRAINT FK_56FBF0A03243BB18 FOREIGN KEY (hotel_id) REFERENCES ho_hotel (id)');
        $this->addSql('CREATE INDEX IDX_56FBF0A03243BB18 ON ho_pricing (hotel_id)');
        $this->addSql('ALTER TABLE ho_pricing_plan DROP FOREIGN KEY FK_234EC4B4DCD6CC49');
        $this->addSql('DROP INDEX IDX_234EC4B4DCD6CC49 ON ho_pricing_plan');
        $this->addSql('ALTER TABLE ho_pricing_plan ADD is_enabled TINYINT(1) NOT NULL, CHANGE branch_id hotel_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_pricing_plan ADD CONSTRAINT FK_234EC4B43243BB18 FOREIGN KEY (hotel_id) REFERENCES ho_hotel (id)');
        $this->addSql('CREATE INDEX IDX_234EC4B43243BB18 ON ho_pricing_plan (hotel_id)');
        $this->addSql('ALTER TABLE ho_reservation DROP FOREIGN KEY FK_201CDA77DCD6CC49');
        $this->addSql('DROP INDEX IDX_201CDA77DCD6CC49 ON ho_reservation');
        $this->addSql('ALTER TABLE ho_reservation CHANGE branch_id hotel_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_reservation ADD CONSTRAINT FK_201CDA773243BB18 FOREIGN KEY (hotel_id) REFERENCES ho_hotel (id)');
        $this->addSql('CREATE INDEX IDX_201CDA773243BB18 ON ho_reservation (hotel_id)');
        $this->addSql('ALTER TABLE ho_reservation_group DROP FOREIGN KEY FK_10185C1FDCD6CC49');
        $this->addSql('DROP INDEX IDX_10185C1FDCD6CC49 ON ho_reservation_group');
        $this->addSql('ALTER TABLE ho_reservation_group ADD is_enabled TINYINT(1) NOT NULL, CHANGE branch_id hotel_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_reservation_group ADD CONSTRAINT FK_10185C1F3243BB18 FOREIGN KEY (hotel_id) REFERENCES ho_hotel (id)');
        $this->addSql('CREATE INDEX IDX_10185C1F3243BB18 ON ho_reservation_group (hotel_id)');
        $this->addSql('ALTER TABLE ho_season ADD hotel_id INT DEFAULT NULL, ADD is_enabled TINYINT(1) NOT NULL');
        $this->addSql('ALTER TABLE ho_season ADD CONSTRAINT FK_9CC2E6513243BB18 FOREIGN KEY (hotel_id) REFERENCES ho_hotel (id)');
        $this->addSql('CREATE INDEX IDX_9CC2E6513243BB18 ON ho_season (hotel_id)');
        $this->addSql('ALTER TABLE ho_source_of_reservation ADD is_enabled TINYINT(1) NOT NULL');
        $this->addSql('ALTER TABLE ho_stay_type DROP FOREIGN KEY FK_29B9C8AFDCD6CC49');
        $this->addSql('DROP INDEX IDX_29B9C8AFDCD6CC49 ON ho_stay_type');
        $this->addSql('ALTER TABLE ho_stay_type ADD is_enabled TINYINT(1) NOT NULL, CHANGE branch_id hotel_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_stay_type ADD CONSTRAINT FK_29B9C8AF3243BB18 FOREIGN KEY (hotel_id) REFERENCES ho_hotel (id)');
        $this->addSql('CREATE INDEX IDX_29B9C8AF3243BB18 ON ho_stay_type (hotel_id)');
        $this->addSql('ALTER TABLE ho_tag DROP FOREIGN KEY FK_21A1BD6DDCD6CC49');
        $this->addSql('DROP INDEX IDX_21A1BD6DDCD6CC49 ON ho_tag');
        $this->addSql('ALTER TABLE ho_tag ADD is_enabled TINYINT(1) NOT NULL, CHANGE branch_id hotel_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_tag ADD CONSTRAINT FK_21A1BD6D3243BB18 FOREIGN KEY (hotel_id) REFERENCES ho_hotel (id)');
        $this->addSql('CREATE INDEX IDX_21A1BD6D3243BB18 ON ho_tag (hotel_id)');
        $this->addSql('ALTER TABLE ho_tag_category DROP FOREIGN KEY FK_E57FF76DDCD6CC49');
        $this->addSql('DROP INDEX IDX_E57FF76DDCD6CC49 ON ho_tag_category');
        $this->addSql('ALTER TABLE ho_tag_category ADD is_enabled TINYINT(1) NOT NULL, CHANGE branch_id hotel_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE ho_tag_category ADD CONSTRAINT FK_E57FF76D3243BB18 FOREIGN KEY (hotel_id) REFERENCES ho_hotel (id)');
        $this->addSql('CREATE INDEX IDX_E57FF76D3243BB18 ON ho_tag_category (hotel_id)');
    }
}
