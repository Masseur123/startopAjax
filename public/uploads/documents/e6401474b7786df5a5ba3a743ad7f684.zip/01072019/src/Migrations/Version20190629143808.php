<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20190629143808 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE bil_invoice DROP FOREIGN KEY FK_7595EA4F3243BB18');
        $this->addSql('ALTER TABLE bil_settlement DROP FOREIGN KEY FK_CD6599B93243BB18');
        $this->addSql('DROP TABLE ho_hotel');
        $this->addSql('DROP INDEX IDX_7595EA4F3243BB18 ON bil_invoice');
        $this->addSql('ALTER TABLE bil_invoice DROP hotel_id');
        $this->addSql('DROP INDEX IDX_CD6599B93243BB18 ON bil_settlement');
        $this->addSql('ALTER TABLE bil_settlement DROP hotel_id');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('CREATE TABLE ho_hotel (id INT AUTO_INCREMENT NOT NULL, user_id INT DEFAULT NULL, name VARCHAR(255) NOT NULL COLLATE utf8mb4_unicode_ci, email VARCHAR(50) DEFAULT NULL COLLATE utf8mb4_unicode_ci, fixphone VARCHAR(30) DEFAULT NULL COLLATE utf8mb4_unicode_ci, mobilephone VARCHAR(30) DEFAULT NULL COLLATE utf8mb4_unicode_ci, pobox VARCHAR(30) DEFAULT NULL COLLATE utf8mb4_unicode_ci, website VARCHAR(50) DEFAULT NULL COLLATE utf8mb4_unicode_ci, address LONGTEXT DEFAULT NULL COLLATE utf8mb4_unicode_ci, taxpayernumber VARCHAR(50) DEFAULT NULL COLLATE utf8mb4_unicode_ci, businessnumber VARCHAR(50) DEFAULT NULL COLLATE utf8mb4_unicode_ci, logo VARCHAR(255) DEFAULT NULL COLLATE utf8mb4_unicode_ci, created_at DATETIME NOT NULL, is_enabled TINYINT(1) NOT NULL, city VARCHAR(255) NOT NULL COLLATE utf8mb4_unicode_ci, INDEX IDX_237B4B8DA76ED395 (user_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE = InnoDB COMMENT = \'\' ');
        $this->addSql('ALTER TABLE ho_hotel ADD CONSTRAINT FK_237B4B8DA76ED395 FOREIGN KEY (user_id) REFERENCES se_user (id)');
        $this->addSql('ALTER TABLE bil_invoice ADD hotel_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE bil_invoice ADD CONSTRAINT FK_7595EA4F3243BB18 FOREIGN KEY (hotel_id) REFERENCES ho_hotel (id)');
        $this->addSql('CREATE INDEX IDX_7595EA4F3243BB18 ON bil_invoice (hotel_id)');
        $this->addSql('ALTER TABLE bil_settlement ADD hotel_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE bil_settlement ADD CONSTRAINT FK_CD6599B93243BB18 FOREIGN KEY (hotel_id) REFERENCES ho_hotel (id)');
        $this->addSql('CREATE INDEX IDX_CD6599B93243BB18 ON bil_settlement (hotel_id)');
    }
}
